<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_options;

get_header(); ?>

<div class="row">
	<div class="columns <?php echo ( $tadam_options["archive-post-display-type"] === 'blog' || is_single() ) ? 'large-8 medium-12 small-12' : '' ; ?>">

	        <div id="primary" class="content-area">
        	        <main id="main" class="site-main" role="main">
			
	                        <?php
        	                if ( have_posts() ) :
			
					if ($tadam_options["archive-post-display-type"] === 'masonry' && !is_single()):
						echo '<div class="tadam-masonry-grid">';
					elseif ($tadam_options["archive-post-display-type"] === 'grid-three' && !is_single()):
						echo '<div class="row blog-grid-three-wrapper">';
					elseif ($tadam_options["archive-post-display-type"] === 'grid-four' && !is_single()):
                                                echo '<div class="row blog-grid-three-wrapper blog-grid-four-wrapper">';
					endif;

        	                        /* Start the Loop */
                	                while ( have_posts() ) : the_post();
	
        	                                /*
                	                         * Include the Post-Format-specific template for the content.
                        	                 * If you want to override this in a child theme, then include a file
                                	         * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                                        	 */
						if ( is_single() ) {
							get_template_part( 'template-parts/post/single-content', get_post_format() );
						}else{
							if ( $tadam_options["archive-post-display-type"] === 'blog-small' && !get_post_format() ){
								get_template_part( 'template-parts/post/blog-small', 'content' );
							}elseif ( $tadam_options["archive-post-display-type"] === 'masonry' && !get_post_format() ){
                                                                get_template_part( 'template-parts/post/masonry', 'content' );
							}elseif ( $tadam_options["archive-post-display-type"] === 'grid-three' && !get_post_format() ){
                                                                get_template_part( 'template-parts/post/grid-three', 'content' );
							}elseif ( $tadam_options["archive-post-display-type"] === 'grid-four' && !get_post_format() ){
                                                                get_template_part( 'template-parts/post/grid-four', 'content' );
							}else{
								get_template_part( 'template-parts/post/content', get_post_format() );
							}
						}
	
        	                        endwhile;

					if (($tadam_options["archive-post-display-type"] === 'masonry' || $tadam_options["archive-post-display-type"] === 'grid-three' || $tadam_options["archive-post-display-type"] === 'grid-four') && !is_single()):
                                                echo '</div> <!-- /.masonry-wrapper || /.row --> ';
                                        endif;
	
					the_posts_pagination( array(
                	                        'prev_text' => tadam_get_svg( array( 'icon' => 'arrow-left' ) ) . '<span class="screen-reader-text">' . __( 'Previous page', 'tadam' ) . '</span>',
                        	                'next_text' => '<span class="screen-reader-text">' . __( 'Next page', 'tadam' ) . '</span>' . tadam_get_svg( array( 'icon' => 'arrow-right' ) ),
                                	        'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>',
	                                ) );
        	                else :
                	                get_template_part( 'template-parts/post/content', 'none' );
	
        	                endif;
                	        ?>

        	        </main><!-- #main -->
	        </div><!-- #primary -->

	</div><!-- /.columns -->

	<?php if( $tadam_options["archive-post-display-type"] === 'blog' || is_single() ): ?>
		<div class="columns large-4 medium-12 small-12">
			<?php get_sidebar(); ?>
		</div>
	<?php endif; ?>
</div>

<?php get_footer();

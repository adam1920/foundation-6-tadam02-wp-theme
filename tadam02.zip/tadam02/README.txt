=== Tadam02 ===
Contributors: the Tadam team
Requires at least: WordPress 4.7
Tested up to: WordPress 4.7
Version: 0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: one-column, right-sidebar, grid-layout, accessibility-ready, custom-menu, custom-logo, featured-images, footer-widgets, post-formats, rtl-language-support, sticky-post, theme-options, translation-ready

== Description ==

Beautiful wordpress theme built on Foundation 6. Fluid grid system. Mobile first. Custom post types: Portfolios, FAQs, Testimonials, Our Team. Custom widgets: Company Profile, Newsletters, Twitter Timeline, Facebook Fans Page, Instagram, Portfolio, Video. 3 menu positions. Customization. Cross-Browser compatible. RTL-Language Support

For more information about Tadam Themes go to http://wp-themes.tadam.co.il

== Installation ==

1. Download zip file.
2. Next login to your WordPress admin area and click on Appearance » Themes.
3. Once you are on the themes page, click on the Add New button at the top.
4. On the next screen, click on the Upload Theme button at the top.
5. You will be prompted to choose the zip file that you downloaded earlier. Select the file and click Install Now.
6. Once your theme is installed, you will see a success message along with the link to activate and preview the theme.
7. Click on the activate button, and you’ve successfully installed and activated your WordPress theme.

== Copyright ==

Tadam02 WordPress Theme, Copyright 2017 Tadam Ltd
Tadam02 is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

Tadam02 bundles the following third-party resources:

Foundation 6, Copyright 1998-2017 ZURB, Inc
Licenses: MIT/GPL2
Source: http://foundation.zurb.com/

Foundation 6, Copyright 1998-2017 ZURB, Inc
Licenses: MIT/GPL2
Source: http://foundation.zurb.com/

CMB2, Copyright WebDevStudio
License: GPLv2 or later
Source: https://github.com/WebDevStudios/CMB2

Foundation 6 Menu Walker Classes for WordPress, Copyright wlcdesigns
License: GPLv2 or later
Source: https://github.com/wlcdesigns/foundation-6-wordpress-menu-walkers

TGM Plugin Activation, Copyright (C) 1989, 1991 Free Software Foundation, Inc.
Licence: GNU GENERAL PUBLIC LICENSE
Source: https://github.com/TGMPA/TGM-Plugin-Activation


== Changelog ==

Initial release

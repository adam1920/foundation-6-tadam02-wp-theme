<?php
/**
 * The template for displaying testimonial archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<div class="row">
        <div class="columns large-8 medium-12 small-12">

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<header class="entry-header">
                                <h1 class="entry-title"><?php tadam_wp_title(); ?></h1>
                        </header>
		<?php
		// get all testimonials
		$portfolio_args = array('post_type' => 'testimonial', 'suppress_filters' => get_option('suppress_filters'), 'nopaging' => 1);
		$query = new WP_Query( $portfolio_args );
		if ($query->have_posts() ) : ?>
			<?php
			/* Start the Loop */
			while ( $query->have_posts() ) : $query->the_post();
				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'template-parts/testimonial/content', get_post_format() );

			endwhile;

			the_posts_pagination( array(
				'prev_text' => tadam_get_svg( array( 'icon' => 'arrow-left' ) ) . '<span class="screen-reader-text">' . __( 'Previous page', 'tadam' ) . '</span>',
				'next_text' => '<span class="screen-reader-text">' . __( 'Next page', 'tadam' ) . '</span>' . tadam_get_svg( array( 'icon' => 'arrow-right' ) ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>',
			) );

		else :

			get_template_part( 'template-parts/testimonial/content', 'none' );

		endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->

        </div><!-- /.columns -->

        <div class="columns large-4 medium-12 small-12">
                <?php get_sidebar('testimonail'); ?>
        </div><!-- /.columns -->
</div><!-- .row -->

<?php get_footer();



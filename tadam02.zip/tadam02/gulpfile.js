var gulp = require('gulp');
var $    = require('gulp-load-plugins')();
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');
var clean = require('gulp-clean');
var sequence = require('run-sequence');


var sassPaths = [
  'bower_components/normalize.scss/sass',
  'bower_components/foundation-sites/scss',
  'bower_components/motion-ui/src'
];

var javascriptPaths = [
        //'bower_components/jquery/dist/jquery.js',
        'bower_components/what-input/dist/what-input.js',
        'bower_components/foundation-sites/dist/js/foundation.min.js',
	'bower_components/isotope/dist/isotope.pkgd.min.js',
        'src/js/*.js'
];

var srcPaths = [
	'src/**/*',
	'!src/{js,scss}/**/*',
	'!src/{js,scss}/'
];

// Delete the "dist" folder
// This happens every time a build starts
gulp.task('clean', function () {
    return gulp.src('dist', {read: false})
        .pipe(clean());
})

gulp.task('sass', function() {
  return gulp.src('src/scss/app.scss')
    .pipe($.sass({
      includePaths: sassPaths,
      outputStyle: 'compressed' // if css compressed **file size**
    })
      .on('error', $.sass.logError))
    .pipe($.autoprefixer({
      browsers: ['last 2 versions', 'ie >= 9']
    }))
    .pipe(gulp.dest('dist/css'));
});

gulp.task('sass-rtl', function() {
  return gulp.src('src/scss/app-rtl.scss')
    .pipe($.sass({
      includePaths: sassPaths,
      outputStyle: 'compressed' // if css compressed **file size**
    })
      .on('error', $.sass.logError))
/*
    .pipe($.autoprefixer({
      browsers: ['last 2 versions', 'ie >= 9']
    }))
*/
    .pipe(gulp.dest('dist/css'));
});

// creating JS from list of files
gulp.task('javascript', function() {
        return gulp.src(javascriptPaths)
        .pipe(concat('all.js'))
        .pipe(uglify())
        .pipe(gulp.dest('dist/js/'));
});

// Copy files out of the src folder
// This task skips over the "img", "js", and "scss" folders, which are parsed separately
gulp.task('copy', function() {
  	return gulp.src(srcPaths)
    	.pipe(gulp.dest('dist'));
});


gulp.task('default', ['clean','sass', 'javascript', 'copy'], function() {
  gulp.watch(['src/scss/**/*.scss'], ['sass']);
  gulp.watch(['src/js/**/*.js'], ['javascript']);
});



/* Build the "dist" folder by running all of the above tasks*/
gulp.task('build', function(done) {
        sequence('clean', ['sass', 'sass-rtl', 'javascript','copy'], done);
});

// Build the site, run the server, and watch for file changes
gulp.task('default', ['build'], function() {
	gulp.watch(['src/scss/**/*.scss'], ['sass', 'sass-rtl']);
	gulp.watch(['src/js/**/*.js'], ['javascript']);
});




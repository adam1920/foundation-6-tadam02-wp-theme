<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<div class="row">
        <div class="columns large-8 medium-12 small-12">

	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">

		<?php
		if ( have_posts() ) :
			/* Start the Loop */
			while ( have_posts() ) : the_post();

				/**
				 * Run the loop for the search to output the results.
				 * If you want to overload this in a child theme then include a file
				 * called content-search.php and that will be used instead.
				 */
				get_template_part( 'template-parts/post/content', 'excerpt' );

			endwhile; // End of the loop.

			the_posts_pagination( array(
				'prev_text' => tadam_get_svg( array( 'icon' => 'arrow-left' ) ) . '<span class="screen-reader-text">' . __( 'Previous page', 'tadam' ) . '</span>',
				'next_text' => '<span class="screen-reader-text">' . __( 'Next page', 'tadam' ) . '</span>' . tadam_get_svg( array( 'icon' => 'arrow-right' ) ),
				'before_page_number' => '<span class="meta-nav screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>',
			) );

		else : ?>
			<p><?php _e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'tadam' ); ?></p>
			<?php get_search_form();?>
		<?php endif;?>

		</main><!-- #main -->
	</div><!-- #primary -->

        </div><!-- /.columns -->

        <div class="columns large-4 medium-12 small-12">
                <?php get_sidebar(); ?>
        </div><!-- /.columns -->
</div><!-- .row -->


<?php get_footer();

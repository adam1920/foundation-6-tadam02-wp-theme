<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars, $tadam_options;
?><!doctype html>
<html <?php language_attributes(); ?> class="no-js">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">

<?php wp_head(); ?>
</head>

<body id="tadam-top" <?php body_class(); ?>>
<?php body_begin(); ?>

<div class="off-canvas position-<?php echo get_theme_mod('off_canvas_position',$tadam_options["off-canvas-position"]);?>" id="offCanvas" data-off-canvas>
	<?php get_template_part( 'template-parts/off-canvas/off-canvas', 'data' ); ?>
</div>
<div id="page" class="site off-canvas-content" data-off-canvas-content>

	<?php get_template_part( 'template-parts/search', 'box' ); ?>

	<div class="site-content-contain">
                <div id="content" class="site-content">

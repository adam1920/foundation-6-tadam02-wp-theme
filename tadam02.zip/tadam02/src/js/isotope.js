jQuery(function(){

	var $grid = jQuery('.tadam-isotope-grid').isotope({
  		// options
	  	itemSelector: '.grid-item',
  		masonry: {
    			columnWidth: '.grid-item',
			isFitWidth: true,
			gutter: 10
		},
		filter: '*'
	});

	var intervalID = setTimeout(function() { $grid.isotope({ filter: '*' }) }, 2000);

	// filter items on button click
	jQuery('.tadam-isotope-filters').on( 'click', 'button', function() {
  		var filterValue = jQuery(this).attr('data-filter');
	  	$grid.isotope({ filter: filterValue });
	});

});


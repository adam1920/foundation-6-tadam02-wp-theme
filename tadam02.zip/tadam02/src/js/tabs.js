jQuery( function() {
    	jQuery( "#product-tabs" ).tabs({
		active: 0
	});
});


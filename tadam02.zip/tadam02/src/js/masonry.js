/*
Using isotope plugin: http://isotope.metafizzy.co/layout.html
*/
jQuery(function(){
	jQuery('.tadam-masonry-grid').isotope({
  		// set itemSelector so .grid-sizer is not used in layout
  		itemSelector: '.post',
  		percentPosition: true,
  		masonry: {
    			// use element for option
    			columnWidth: '.post'
  		}
	});
});

jQuery('a[href^=#]').click(function () {

	if (jQuery(this).attr('target') == 'blank'){
		return true;
	}

	jQuery('html, body').animate({
        	scrollTop: jQuery( jQuery(this).attr('href') ).offset().top
    	}, 600);

	/*
        jQuery("html, body").animate({
            	scrollTop: 0
        }, 600);
	*/
        return false;
});

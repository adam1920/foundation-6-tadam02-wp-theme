(function( $ ) {

	// Variables and DOM Caching.
        var $body = $( 'body' );

        // Add header video class after the video is loaded.
        $( document ).on( 'wp-custom-header-video-loaded', function() {
                $body.addClass( 'has-header-video' );
        });

})( jQuery );

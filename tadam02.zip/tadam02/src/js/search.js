jQuery('.search-btn.slide-down').click(function(){
	// find search-box + add class active
	jQuery('.search-box').addClass('active');
});
jQuery('.search-box .close-button').click(function(){	
	jQuery(this).closest('.search-box').removeClass('active');
});

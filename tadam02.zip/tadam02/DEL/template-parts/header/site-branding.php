<?php
/**
 * Displays header title with breadcrumbs
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<div class="site-branding">
	<header class="page-header">
		<p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo('name'); ?></a></p>
		<?php
		$description = get_bloginfo( 'description', 'display' );
        	if ( $description || is_customize_preview() ) : ?>
		        <p class="site-description"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php echo $description; ?></a></p>
        	<?php endif; ?>
		<h1 class="page-title"><?php tadam_wp_title(); ?></h1>
	
		<?php if ( !is_front_page() && function_exists('yoast_breadcrumb') ) {
			yoast_breadcrumb('<p id="breadcrumbs">','</p>');
		} ?>
	</header>
</div>


<?php
/**
 * Displays header media
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<div class="custom-header">
	<div class="custom-header-media">
		<?php the_custom_header_markup(); ?>
	</div>
        <?php get_template_part( 'template-parts/header/site', 'branding'); ?>
</div><!-- .custom-header -->

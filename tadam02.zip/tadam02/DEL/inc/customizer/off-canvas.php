<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/* Off-canvas */
if (!function_exists('tadam_customize_register_off_canvas')):
function tadam_customize_register_off_canvas( $wp_customize ) {
        global $tadam_vars;

        $wp_customize->add_setting( 'off_canvas_position', array(
                'default'           => $tadam_vars["customize"]["default_off_canvas_position"],
                'transport'         => 'refresh',
                'sanitize_callback' => 'tadam_sanitize_off_canvas_position',
        ) );
        $wp_customize->add_control( 'off_canvas_position', array(
                'type'          => 'radio',
                'label'         => _x( 'Off-canvas position', 'admin section', 'tadam' ),
                'choices'  => array(
                        'left'  => __( 'Left', 'tadam' ),
                        'right' => __( 'Right', 'tadam' ),
                ),
                'section'       => 'tadam_off_canvas',
        ) );

	$wp_customize->add_setting( 'off_canvas_logo', array(
                'default'       	=> $tadam_vars["customize"]["default_off_canvas_logo"],
		'sanitize_callback' 	=> 'tadam_sanitize_off_canvas_logo',
        ) );
	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'off_canvas_logo', array(
                'label'         => _x('Off-canvas logo', 'admin section', 'tadam'),
                'description'   => _x('Recommended size 160 pixels wide and 70 pixels tall.', 'admin section', 'tadam'),
                'section'       => 'tadam_off_canvas',
                'priority'      => 15,
        )) );


        $wp_customize->add_section( 'tadam_off_canvas' , array(
                'title'         => _x( 'Off-canvas', 'admin section', 'tadam' )
        ) );
}
endif;
add_action( 'customize_register', 'tadam_customize_register_off_canvas' );


/**
 * Sanitize the off-canvas position.
 */
if (!function_exists('tadam_sanitize_off_canvas_position')):
function tadam_sanitize_off_canvas_position( $input ) {
        $valid = array( 'left', 'right' );

        if ( in_array( $input, $valid ) ) {
                return $input;
        }

        return 'left';
}
endif;

/**
 * Sanitize the off-canvas position.
 */
if (!function_exists('tadam_sanitize_off_canvas_logo')):
function tadam_sanitize_off_canvas_logo( $input ) {
	return $input;
}
endif;


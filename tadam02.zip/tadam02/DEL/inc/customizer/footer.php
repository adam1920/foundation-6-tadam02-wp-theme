<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/* Footer */
if (!function_exists('tadam_customize_register_footer')):
function tadam_customize_register_footer( $wp_customize ) {
        global $tadam_vars;

        // = background image =
        $wp_customize->add_setting( 'footer_bkg_image', array(
                'default'       => $tadam_vars["customize"]["default_footer_bkg_image"]
        ) );
        $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'footer_bkg_image', array(
                'label'         => __('Background Image', 'tadam'),
                'description'   => _x('Recommended size 2000 pixels wide and 760 pixels tall.', 'admin section', 'tadam'),
                'section'       => 'tadam_footer',
                'priority'      => 15,
        )) );

	// = copyrights  =
        $wp_customize->add_setting( 'footer_copyrights', array(
                'default'               => $tadam_vars["customize"]["default_footer_copyrights"],
                'transport'             => 'refresh'
        ) );
        $wp_customize->add_control( 'footer_copyrights', array(
                'type'          => 'textarea',
                'section'       => 'tadam_footer',
                'label'         => _x( 'Copyright text', 'admin section', 'tadam' ),
                'description'   => _x( 'May include html tags.', 'admin section', 'tadam' ),
                'priority'      => 15
        ) );

        $wp_customize->add_section( 'tadam_footer' , array(
                'title'      => __( 'Footer', 'tadam' )
        ) );
}
endif;
add_action( 'customize_register', 'tadam_customize_register_footer' );


<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
global $tadam_options;
$row_class = $column_class = '';
$is_sidebar = false;

$is_sidebar_to_show = !WC_Tadam::is_woocommerce() && ($tadam_options["single-page-layout"] === 'sidebar-right' || $tadam_options["single-page-layout"] === 'sidebar-left');

if ( $tadam_options["single-page-layout"] === 'sidebar-right' || $tadam_options["single-page-layout"] === 'sidebar-left' ){
        $column_class = 'large-8 medium-12 small-12';
        $is_sidebar = true;
}elseif ($tadam_options["single-page-layout"] === '100-width'){
        $row_class = 'full-width';
}

if (get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix"] . 'blank_page', true ) === 'on'){
	get_header('blank');
}else{
	get_header(); 
}

?>
<div class="row <?php echo $row_class; ?>">
	<div class="columns <?php echo $column_class; ?>">

		<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">

				<?php
				while ( have_posts() ) : the_post();

					get_template_part( 'template-parts/page/content', 'page' );
	
					get_template_part( 'template-parts/post/comments');

				endwhile; // End of the loop.
				?>

		</main><!-- #main -->
	</div><!-- #primary -->

	</div><!-- /.columns -->

	<?php if( $is_sidebar ): ?>
		<div class="columns large-3 medium-12 small-12">
        	        <?php get_sidebar('page'); ?>
	        </div><!-- /.columns -->
	<?php endif; ?>
</div><!-- .row -->

<?php 
if (get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix"] . 'blank_page', true ) === 'on'){
        get_footer('blank');
}else{
        get_footer(); 
}


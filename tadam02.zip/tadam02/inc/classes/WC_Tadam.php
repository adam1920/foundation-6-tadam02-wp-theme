<?php
class WC_Tadam{
	public static function woocommerce_output_content_wrapper(){
		ob_start();
		?>		
		<div class="row full-width">
       		<div class="columns large-9 medium-12 small-12">
        	<div id="primary" class="content-area">
               	<main id="main" class="site-main" role="main">
		<?php
		echo ob_get_clean();
	}

	public static function woocommerce_output_content_wrapper_end(){
		ob_start();
		?>
		</main><!-- #main -->
	        </div><!-- #primary -->
	        </div><!-- /.columns -->
		<?php
		echo ob_get_clean();
	}

	public static function woocommerce_sidebar_wrapper(){
		ob_start();
		?>
			<div class="columns large-3 medium-12 small-12">
		<?php	
		echo ob_get_clean();
	}
	
	public static function woocommerce_sidebar_wrapper_end(){
                ob_start();
		?>
			</div><!-- /.columns -->
			</div><!-- .row -->
		<?php
                echo ob_get_clean();
        }

	public static function is_woocommerce(){
		if (!function_exists('is_cart') || !function_exists('is_checkout') || !function_exists('is_account_page')) return false;
		return ( is_cart() || is_checkout() || is_account_page() );
	}

	public static function woocommerce_output_add_to_cart_button(){
                ob_start();
                ?>
		<div class="input-group">
                <?php
                echo ob_get_clean();
        }
	public static function woocommerce_output_add_to_cart_button_end(){
                ob_start();
                ?>
		</div><!-- /.input-group -->
                <?php
                echo ob_get_clean();
        }

	public static function woocommerce_output_single_product_summary(){
		ob_start();
                ?>
			<footer class="entry-footer">
                <?php
                echo ob_get_clean();
	}

	public static function woocommerce_output_single_product_summary_end(){
                ob_start();
                ?>
                        </footer><!-- /.entry-footer -->
                <?php
                echo ob_get_clean();
        }

	public static function woocommerce_template_loop_product_thumbnail_wrapper(){
		ob_start();
		?>
			<div class="item-img-info">
		<?php
		echo ob_get_clean();
	}

	public static function woocommerce_template_loop_product_thumbnail_wrapper_end(){
                ob_start();
                ?>
                        </div> <!-- /.item-img-info -->
                <?php
                echo ob_get_clean();
        }

	public static function woocommerce_template_loop_product_box_hover(){
		global $product, $yith_wcwl;

		ob_start();
                ?>
		<div class="box-hover">

	        	<ul class="add-to-links">
                        	<li>
                       		<?php if (class_exists('YITH_WCQV_Frontend')) { ?>
					<a class="detail-bnt yith-wcqv-button link-quickview" data-product_id="<?php echo esc_html($product->get_id());?>"><span class="show-for-sr"><?php esc_attr_e('Quick View', 'tadam'); ?></span></a>
                       		<?php } ?>
                          	</li>

				<li>
                            	<?php if (isset($yith_wcwl) && is_object($yith_wcwl)) {
                                ?>
					<a title="<?php esc_attr_e('Add to Wishlist','tadam');?>" href="<?php echo esc_url( add_query_arg( 'add_to_wishlist', $product->get_id() ) ); ?>"  data-product-id="<?php echo esc_html($product->get_id()); ?>" class="link-wishlist"><span class="show-for-sr"><?php esc_attr_e('Add to Wishlist', 'tadam'); ?></span></a>

                            	<?php } ?>
                         	</li>
                          	<li>
                            	<?php if (class_exists('YITH_Woocompare_Frontend')) {
	                                $mgk_yith_cmp = new YITH_Woocompare_Frontend; ?>

					<a title="<?php esc_attr_e('Add to Compare','tadam');?>" href="<?php echo esc_url($mgk_yith_cmp->add_product_url($product->get_id())); ?>" class="link-compare add_to_compare compare" data-product_id="<?php echo esc_html($product->get_id()); ?>"><span class="show-for-sr"><?php esc_attr_e('Add to Compare', 'tadam'); ?></span></a>

                            	<?php } ?>
                          	</li>
	                </ul>

               </div>

		<?php echo ob_get_clean();
	}

}



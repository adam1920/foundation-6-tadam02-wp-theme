<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Register a Our Team  Post Type
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
if (!function_exists('our_team_post_type')):
function our_team_post_type() {

        $labels = array(
                'name'                => _x( 'Our Team', 'Post Type General Name', 'tadam' ),
                'singular_name'       => _x( 'Our Team', 'Post Type Singular Name', 'tadam' ),
                'menu_name'           => __( 'Our Team', 'tadam' ),
                'parent_item_colon'   => __( 'Parent of our team:', 'tadam' ),
                'all_items'           => __( 'All our team members', 'tadam' ),
                'view_item'           => __( 'View our team member', 'tadam' ),
                'add_new_item'        => __( 'Add New our team member', 'tadam' ),
                'add_new'             => __( 'Add New', 'tadam' ),
                'edit_item'           => __( 'Edit Item', 'tadam' ),
                'update_item'         => __( 'Update our team member', 'tadam' ),
                'search_items'        => __( 'Search our team member', 'tadam' ),
                'not_found'           => __( 'Not found', 'tadam' ),
                'not_found_in_trash'  => __( 'Not found in Trash', 'tadam' ),
        );
        $args = array(
                'label'               => __( 'our team', 'tadam' ),
               	'description'         => __( 'Our Team Post Type', 'tadam' ),
                'labels'              => $labels,
                'supports'            => array( 'title', 'editor', 'thumbnail'),
                'hierarchical'        => false,
                'public'              => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => true,
                'show_in_admin_bar'   => true,
                'menu_position'       => 8,
        	'menu_icon'           => 'dashicons-image-filter',
                'can_export'          => true,
                'has_archive'         => true,
                'exclude_from_search' => false,
                'publicly_queryable'  => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'our_team' ),
		'capability_type'    => 'post',
        );

        register_post_type( 'our_team', $args );

}
endif;
add_action( 'init', 'our_team_post_type', 0 );

// Register Taxonomies
if (!function_exists('create_our_team_taxonomies')):
function create_our_team_taxonomies() {
	// Add category
        $labels = array(
                'name'                       => _x( 'Our Team Departments', 'Taxonomy General Name', 'tadam' ),
                'singular_name'              => _x( 'Our Team Department', 'Taxonomy Singular Name', 'tadam' ),
                'menu_name'                  => __( 'Departments', 'tadam' ),
                'all_items'                  => __( 'All Departments', 'tadam' ),
                'parent_item'                => __( 'Parent Department', 'tadam' ),
                'parent_item_colon'          => __( 'Parent Department:', 'tadam' ),
                'new_item_name'              => __( 'New Department Name', 'tadam' ),
                'add_new_item'               => __( 'Add New Department', 'tadam' ),
                'edit_item'                  => __( 'Edit Department', 'tadam' ),
                'update_item'                => __( 'Update Department', 'tadam' ),
                'separate_items_with_commas' => __( 'Separate Departments with commas', 'tadam' ),
                'search_items'               => __( 'Search Departments', 'tadam' ),
                'add_or_remove_items'        => __( 'Add or remove Departments', 'tadam' ),
                'choose_from_most_used'      => __( 'Choose from the most used departments', 'tadam' ),
                'not_found'                  => __( 'Not Found', 'tadam' ),
        );
        $args = array(
                'labels'                     => $labels,
                'hierarchical'               => true,
                'public'                     => true,
                'show_ui'                    => true,
                'show_admin_column'          => true,
                'show_in_nav_menus'          => true,
                'show_tagcloud'              => true,
                'rewrite'                    => true,
                'query_var'                  => true
        );
        register_taxonomy( 'our_team_department', 'our_team', $args );
}
endif;
add_action( 'init', 'create_our_team_taxonomies', 0);

if (!function_exists('cmb2_our_team_metaboxes')):
function cmb2_our_team_metaboxes(){
        global $tadam_vars;
        // Start with an underscore to hide fields from custom fields list
        $prefix = $tadam_vars["metaboxes_prefix"];

	/**
     	* Initiate the metabox
     	*/
    	$cmb = new_cmb2_box( array(
        	'id'            => 'tadam_our_team_metabox',
	        'title'         => _x( 'Our Team Member Data', 'admin section', 'tadam' ),
        	'object_types'  => array( 'our_team', ), // Post type
	        'context'       => 'normal',
        	'priority'      => 'high',
	        'show_names'    => true, // Show field names on the left
        	// 'cmb_styles' => false, // false to disable the CMB stylesheet
	        // 'closed'     => true, // Keep the metabox closed by default
    	) );

	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( "Member's position", 'admin section', 'tadam' ),
                'desc'       => _x( "Input members's position.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'our_team_member_position',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );
	
	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( "Member's phone", 'admin section', 'tadam' ),
                'desc'       => _x( "Input members's phone.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'our_team_member_phone',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );

	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( "Member's email", 'admin section', 'tadam' ),
                'desc'       => _x( "Input members's email.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'our_team_member_email',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );

	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( "Member's facebook url", 'admin section', 'tadam' ),
                'desc'       => _x( "Input members's facebook url.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'our_team_member_facebook_url',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );

	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( "Member's twitter url", 'admin section', 'tadam' ),
                'desc'       => _x( "Input members's twitter url.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'our_team_member_twitter_url',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );

	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( "Member's google+ url", 'admin section', 'tadam' ),
                'desc'       => _x( "Input members's google+ url.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'our_team_member_googleplus_url',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );

	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( "Member's linkedin url", 'admin section', 'tadam' ),
                'desc'       => _x( "Input members's linkedin url.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'our_team_member_linkedin_url',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );

	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( "Member's github url", 'admin section', 'tadam' ),
                'desc'       => _x( "Input members's github url.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'our_team_member_github_url',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );
}
endif;
add_action( 'cmb2_admin_init', 'cmb2_our_team_metaboxes' );


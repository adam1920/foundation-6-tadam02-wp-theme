<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Replaces "[...]" (appended to automatically generated excerpts) with ... and
 * a 'Continue reading' link.
 *
 * @since Tadam 0.1
 *
 * @return string 'Continue reading' link prepended with an ellipsis.
 */
function tadam_excerpt_more( $link ) {
        if ( is_admin() ) {
                return $link;
        }

        $link = sprintf( '<p class="link-more"><a href="%1$s" class="more-link">%2$s</a></p>',
                esc_url( get_permalink( get_the_ID() ) ),
                /* translators: %s: Name of current post */
                sprintf( __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'tadam' ), get_the_title( get_the_ID() ) )
        );
        return ' &hellip; ' . $link;
}
add_filter( 'excerpt_more', 'tadam_excerpt_more' );

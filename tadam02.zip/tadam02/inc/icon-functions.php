<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Return tag.
 *
 * @param array $args {
 *     Parameters needed to display an icon.
 *
 *     @type string $icon  Required icon filename.
 * }
 * @return icon tag
 */
function tadam_get_svg( $args = array() ) {
        // Make sure $args are an array.
        if ( empty( $args ) ) {
                return __( 'Please define default parameters in the form of an array.', 'tadam' );
        }

        // Define an icon.
        if ( false === array_key_exists( 'icon', $args ) ) {
                return __( 'Please define an icon filename.', 'tadam' );
        }

        // Set defaults.
        $defaults = array(
                'icon'        => ''
        );

        // Parse args.
        $args = wp_parse_args( $args, $defaults );

        // Set aria hidden.
        $aria_hidden = ' aria-hidden="true"';

	return '<i class="icon fa fa-'.$args["icon"].'" '.$aria_hidden.'></i>';
}

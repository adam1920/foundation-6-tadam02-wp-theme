<?php
/**
 * Tadam Template Hooks
 *
 * https://developer.wordpress.org/reference/hooks/
*/

if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
}
add_action('comment_form_submit_button', 'tadam_comment_form_submit_button');

function tadam_comment_form_submit_button($button){
        $str  = str_replace('class="', 'class="button ', $button);
        return $str;
}


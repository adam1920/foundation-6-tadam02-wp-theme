<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Register a FAQ Post Type
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
if (!function_exists('faq_post_type')):
function faq_post_type() {

        $labels = array(
                'name'                => _x( 'FAQs', 'Post Type General Name', 'tadam' ),
                'singular_name'       => _x( 'FAQ', 'Post Type Singular Name', 'tadam' ),
                'menu_name'           => __( 'FAQs', 'tadam' ),
                'parent_item_colon'   => __( 'Parent faq:', 'tadam' ),
                'all_items'           => __( 'All faqs', 'tadam' ),
                'view_item'           => __( 'View faq', 'tadam' ),
                'add_new_item'        => __( 'Add New faq', 'tadam' ),
                'add_new'             => __( 'Add New', 'tadam' ),
                'edit_item'           => __( 'Edit Item', 'tadam' ),
                'update_item'         => __( 'Update faq', 'tadam' ),
                'search_items'        => __( 'Search faq', 'tadam' ),
                'not_found'           => __( 'Not found', 'tadam' ),
                'not_found_in_trash'  => __( 'Not found in Trash', 'tadam' ),
        );
        $args = array(
                'label'               => __( 'faq', 'tadam' ),
               	'description'         => __( 'FAQ Post Type', 'tadam' ),
                'labels'              => $labels,
                'supports'            => array( 'title', 'editor'),
                'hierarchical'        => false,
                'public'              => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => true,
                'show_in_admin_bar'   => true,
                'menu_position'       => 6,
        	'menu_icon'           => 'dashicons-welcome-learn-more',
                'can_export'          => true,
                'has_archive'         => true,
                'exclude_from_search' => false,
                'publicly_queryable'  => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'faq' ),
		'capability_type'    => 'post',
        );

        register_post_type( 'faq', $args );

}
endif;
add_action( 'init', 'faq_post_type', 0 );


// Register FAQ taxonomies
if (!function_exists('create_faq_taxonomies')):
function create_faq_taxonomies() {
	// Add new taxonomy, NOT hierarchical (like tags)
        $labels = array(
                'name' => _x( 'FAQ Tags', 'taxonomy general name', 'tadam' ),
                'singular_name' => _x( 'Tag', 'taxonomy singular name', 'tadam' ),
                'search_items' =>  __( 'Search Tags', 'tadam' ),
                'popular_items' => __( 'Popular Tags', 'tadam' ),
                'all_items' => __( 'All Tags', 'tadam' ),
                'parent_item' => null,
                'parent_item_colon' => null,
                'edit_item' => __( 'Edit Tag', 'tadam' ),
                'update_item' => __( 'Update Tag', 'tadam' ),
                'add_new_item' => __( 'Add New Tag', 'tadam' ),
                'new_item_name' => __( 'New Tag Name', 'tadam' ),
                'separate_items_with_commas' => __( 'Separate tags with commas', 'tadam' ),
                'add_or_remove_items' => __( 'Add or remove tags', 'tadam' ),
                'choose_from_most_used' => __( 'Choose from the most used tags', 'tadam' ),
                'menu_name' => __( 'Tags', 'tadam' ),
        );

        $args = array(
                'hierarchical'          => false,
                'labels'                => $labels,
                'show_ui'               => true,
                'show_admin_column'     => true,
                'update_count_callback' => '_update_post_term_count',
                'query_var'             => true,
                'rewrite'               => true,
        );

        register_taxonomy( 'faq_tag', 'faq', $args );
}
endif;
add_action( 'init', 'create_faq_taxonomies', 0);





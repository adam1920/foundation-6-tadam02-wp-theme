<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( !function_exists('tadam_widgets_init') ):
/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function tadam_widgets_init() {
	register_sidebar( array(
                'name'          => _x( 'Main Sidebar', 'admin section', 'tadam' ),
                'id'            => 'sidebar-main',
                'description'   => _x( 'Add widgets here to appear in your sidebar.', 'admin section', 'tadam' ),
		'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );
	register_sidebar( array(
                'name'          => _x( 'Page Sidebar', 'admin section', 'tadam' ),
                'id'            => 'sidebar-page',
                'description'   => _x( 'Add widgets here to appear in your sidebar on single page.', 'admin section', 'tadam' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );
	register_sidebar( array(
                'name'          => _x( 'FAQ Sidebar', 'admin section', 'tadam' ),
                'id'            => 'sidebar-faq',
                'description'   => _x( 'Add widgets here to appear in your sidebar on FAQ single page.', 'admin section', 'tadam' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );
	register_sidebar( array(
                'name'          => _x( 'Testimonial Sidebar', 'admin section', 'tadam' ),
                'id'            => 'sidebar-testimonial',
                'description'   => _x( 'Add widgets here to appear in your sidebar on testimonial single page.', 'admin section', 'tadam' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );
	register_sidebar( array(
                'name'          => _x( 'Shop Sidebar', 'admin section', 'tadam' ),
                'id'            => 'sidebar-shop',
                'description'   => _x( 'Add widgets here to appear in your sidebar on shops pages.', 'admin section', 'tadam' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );
	register_sidebar( array(
                'name' => _x( 'Footer One', 'admin section', 'tadam' ),
                'id' => 'footer-one',
                'description' => _x( 'An optional widget area for your site footer', 'admin section', 'tadam' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );

        register_sidebar( array(
                'name' => _x( 'Footer Two', 'admin section', 'tadam' ),
                'id' => 'footer-two',
                'description' => _x( 'An optional widget area for your site footer', 'admin section', 'tadam' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );

        register_sidebar( array(
                'name' => _x( 'Footer Three', 'admin section', 'tadam' ),
                'id' => 'footer-three',
                'description' => _x( 'An optional widget area for your site footer', 'admin section', 'tadam' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );

        register_sidebar( array(
                'name' => _x( 'Footer Four', 'admin section', 'tadam' ),
                'id' => 'footer-four',
                'description' => _x( 'An optional widget area for your site footer', 'admin section', 'tadam' ),
                'before_widget' => '<div id="%1$s" class="widget %2$s clearfix">',
                'after_widget' => "</div>",
                'before_title' => '<h4 class="widgettitle">',
                'after_title' => '</h4>'
        ) );
}
endif;
add_action( 'widgets_init', 'tadam_widgets_init' );


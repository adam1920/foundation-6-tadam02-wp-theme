<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Additional features to allow styling of the templates
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 */

/**
 * Checks to see if we're on the homepage or not.
 */
function tadam_is_frontpage() {
        return ( is_front_page() && ! is_home() );
}

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function tadam_body_classes( $classes ) {
        // Add class of group-blog to blogs with more than 1 published author.
        if ( is_multi_author() ) {
                $classes[] = 'group-blog';
        }

        // Add class of hfeed to non-singular pages.
        if ( ! is_singular() ) {
                $classes[] = 'hfeed';
        }

        // Add class on front page.
        if ( is_front_page() && 'posts' !== get_option( 'show_on_front' ) ) {
                $classes[] = 'tadam-front-page';
        }

        // Add a class if there is a custom header.
        if ( has_header_image() ) {
                $classes[] = 'has-header-image';
        }

        return $classes;
}
add_filter( 'body_class', 'tadam_body_classes' );


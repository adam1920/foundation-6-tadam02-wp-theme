<?php
/* 
 * Social share
*/

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// based on: http://crunchify.com/how-to-create-social-sharing-button-without-any-plugin-and-script-loading-wordpress-speed-optimization-goal/

if (!function_exists('tadam_social_share')):
function tadam_social_share(){
        global $tadam_vars;
	
	$socialURL = urlencode(get_permalink());
	// Get current page title
	$socialTitle = str_replace( ' ', '%20', get_the_title());
	// Get Post Thumbnail for pinterest
	$socialThumbnail = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ), 'full' );

	$social_arr = Array();

	// Construct sharing URL without using any script
	$tadam_vars["social_arr"]["twitter"]["url"]     = 'https://twitter.com/intent/tweet?text='.$socialTitle.'&amp;url='.$socialURL;
	$tadam_vars["social_arr"]["facebook"]["url"]    = 'https://www.facebook.com/sharer/sharer.php?u='.$socialURL;
	$tadam_vars["social_arr"]["google_plus"]["url"] = 'https://plus.google.com/share?url='.$socialURL;
	$tadam_vars["social_arr"]["whatsapp"]["url"]    = 'whatsapp://send?text='.$socialTitle . ' ' . $socialURL;
	$tadam_vars["social_arr"]["linkedin"]["url"]    = 'https://www.linkedin.com/shareArticle?mini=true&url='.$socialURL.'&amp;title='.$socialTitle;
	$tadam_vars["social_arr"]["pinterest"]["url"]   = 'https://pinterest.com/pin/create/button/?url='.$socialURL.'&amp;media='.$socialThumbnail[0].'&amp;description='.$socialTitle;

        ob_start();

	if ($tadam_vars["social_arr"]):
		?>
		<div class="social-share-wrapper">
		<ul class="social-share-links">
                        <li><span class="social-label label"><?php _e('Share', 'tadam'); ?>:</span></li>
                        <?php foreach($tadam_vars["social_arr"] as $key => $item){
                                if (!isset($item["url"]) || !isset($item["class"])) continue;
                        ?>
                                <li><a href="javascript:void(0)" onclick="window.open('<?php echo $item["url"]; ?>','sharer', 'toolbar=0,status=0,width=620,height=280');"
				class="badge <?php echo $item["class"]; ?>"><span class="screen-reader-text"><?php echo $key; ?></span></a></li>
                        <?php
                        }
                        ?>
                </ul>
		</div>
		<?php
	endif;

        echo ob_get_clean();
}
endif;



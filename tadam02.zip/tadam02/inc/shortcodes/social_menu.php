<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!function_exists('tadam_social_menu')):
function tadam_social_menu(){
	$menu = wp_nav_menu(array(
                'container' => false,                           // Remove nav container
                'container_class' => '',                        // Class of container
                'menu' => '',                                   // Menu name
                'menu_class' => 'social-navigation tadam-list-menu',              // Adding custom nav class
                'theme_location' => 'social-menu',        // Where it's located in the theme
                'before' => '',                                 // Before each link <a>
                'after' => '',                                  // After each link </a>
                'link_before' => '<span class="screen-reader-text">',                            // Before each link text
                'link_after' => '</span>',                             // After each link text
                'depth' => 1,                                   // Limit the depth of the nav
                'fallback_cb' => false,                         // Fallback function (see below)
                'walker' => '',
            ));	
}
endif;


<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!function_exists('tadam_user')):
function tadam_user($wrapper=true, $li_class=null){
        global $tadam_vars, $woocommerce;;

        ob_start();

	if ($wrapper):
		echo '<ul class="user-menu tadam-list-menu">';
	endif;

	if ( is_user_logged_in() ) {
		if (class_exists( 'WooCommerce' ) && is_woocommerce()){
			$myaccount_page_id = get_option( 'woocommerce_myaccount_page_id' );
 
			if ( $myaccount_page_id ) {
   				$logout_url = wp_logout_url( get_permalink( $myaccount_page_id ) );
  				if ( get_option( 'woocommerce_force_ssl_checkout' ) == 'yes' ){
    					$logout_url = str_replace( 'http:', 'https:', $logout_url );
				}
			}


			echo '<li class="'.esc_attr($li_class).'"><a href="' . $logout_url . '" title="'.esc_attr__( 'Log Out', 'tadam' ).'"><i class="fa fa-sign-out" aria-hidden="true"></i></a></li>';
			echo '<li class="'.esc_attr($li_class).'"><a href="' . get_permalink( get_option('woocommerce_myaccount_page_id') ) . '" title="'.esc_attr__( 'My Account', 'tadam' ).'"><i class="fa fa-user" aria-hidden="true"></i></a></li>';
		}else{
			echo '<li class="'.esc_attr($li_class).'"><a href="' . wp_logout_url() . '" title="'.esc_attr__( 'Log Out', 'tadam' ).'"><i class="fa fa-sign-out" aria-hidden="true"></i></a></li>';
			echo '<li class="'.esc_attr($li_class).'"><a href="' . get_edit_user_link() . '" title="'.esc_attr__( 'Edit My Profile', 'tadam' ).'"><i class="fa fa-user" aria-hidden="true"></i></a></li>';
		}
	} else {
		echo '<li class="'.esc_attr($li_class).'"><a href="' . wp_login_url() . '" title="'.esc_attr__( 'Login In', 'tadam' ).'"><i class="fa fa-sign-in" aria-hidden="true"></i></a></li>';
		echo '<li class="'.esc_attr($li_class).'"><a href="' . wp_registration_url() . '" title="'.esc_attr__( 'Sign Up', 'tadam' ).'"><i class="fa fa-user-plus" aria-hidden="true"></i></a></li>';
	}

	if( class_exists( 'WooCommerce' )){
		echo '<li class="'.esc_attr($li_class).'"><a href="' . $woocommerce->cart->get_cart_url() . '" title="'.esc_attr__( 'Cart', 'tadam' ).'"><i class="fa fa-shopping-cart" aria-hidden="true"></i></a></li>';
	}

	if (get_option('yith_wcwl_wishlist_page_id')){
		echo '<li class="'.esc_attr($li_class).'"><a href="' . get_permalink( get_option('yith_wcwl_wishlist_page_id') ) . '" title="'.esc_attr__( 'Wishlist', 'tadam' ).'"><i class="fa fa-heart" aria-hidden="true"></i></a></li>';

	}
	
	if ($wrapper):
		echo '</ul>';
	endif;

        return ob_get_clean();
}
endif;

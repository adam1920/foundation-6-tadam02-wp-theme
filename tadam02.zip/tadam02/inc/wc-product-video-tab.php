<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Custom Tabs for Product display
 * 
 * Outputs an extra tab to the default set of info tabs on the single product page.
 * DOCS: http://www.benblanco.com/how-to-add-custom-product-tab-to-woocommerce-single-product-page/
 */
function video_custom_tab_options_tab() {
?>
        <li class="video_options video_tab"><a href="#video_product_data"><span><?php _e('Video', 'tadam'); ?></span></a></li>
<?php
}
add_action('woocommerce_product_write_panel_tabs', 'video_custom_tab_options_tab');


/**
 * Custom Tab Options
 * 
 * Provides the input fields and add/remove buttons for custom tabs on the single product page.
 */
function video_custom_tab_options() {
        global $post;

        $video_custom_tab_options = array(
                'content' => get_post_meta($post->ID, 'video_custom_tab_content', true),
        );

?>
        <div id="video_product_data" class="panel woocommerce_options_panel">
                <div class="options_group custom_tab_options">
                        <p class="form-field label"><label><?php _e('Video links:', 'tadam'); ?></label> <span class="description"><?php _e('Put one link on row', 'tadam'); ?></span></p>
                        <textarea class="theEditor ltr" style="direction:ltr;width:100%;height:150px;" name="video_custom_tab_content"><?php echo $video_custom_tab_options['content']; ?></textarea>
                </div>
        </div>
<?php
}
add_action('woocommerce_product_data_panels', 'video_custom_tab_options');

/**
 * Process meta
 * 
 * Processes the custom tab options when a post is saved
 */
function process_product_meta_video_custom_tab( $post_id ) {
        update_post_meta( $post_id, 'video_custom_tab_content', $_POST['video_custom_tab_content']);
}
add_action('woocommerce_process_product_meta', 'process_product_meta_video_custom_tab');


add_filter( 'woocommerce_product_tabs', 'woocommerce_video_custom_product_tabs' );
function woocommerce_video_custom_product_tabs( $tabs = array() ) {
        $tabs["video"] = Array('title' => __('Video', 'tadam').' ('.get_video_custom_tab_count().')', 'priority' => 40, 'callback' => 'video_custom_tab_callback');

        return $tabs;
}

function video_custom_tab_callback(){
        global $post, $wp_embed;
        $post_embed = '';
        $video_links = _trim_array(explode("\n",get_post_meta($post->ID, 'video_custom_tab_content', true)));

        if ($video_links){
                foreach ($video_links as $video_link){
                        $video_link = trim($video_link);
                        if (!$video_link) continue;
                        $post_embed .= $wp_embed->run_shortcode('[embed]'.$video_link.'[/embed]');
                }
        }
        echo $post_embed;
}

function get_video_custom_tab_count(){
        global $post;
        $cnt = 0;
        $video_links = _trim_array(explode("\n",get_post_meta($post->ID, 'video_custom_tab_content', true)));

        if ($video_links){
                foreach ($video_links as $video_link){
                        $video_link = trim($video_link);
                        if (!$video_link) continue;
                        $cnt++;
                }
        }
        return $cnt;
}


<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Register a Testimonial Post Type
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
if (!function_exists('testimonial_post_type')):
function testimonial_post_type() {

        $labels = array(
                'name'                => _x( 'Testimonials', 'Post Type General Name', 'tadam' ),
                'singular_name'       => _x( 'Testimonial', 'Post Type Singular Name', 'tadam' ),
                'menu_name'           => __( 'Testimonials', 'tadam' ),
                'parent_item_colon'   => __( 'Parent testimonial:', 'tadam' ),
                'all_items'           => __( 'All testimonials', 'tadam' ),
                'view_item'           => __( 'View testimonial', 'tadam' ),
                'add_new_item'        => __( 'Add New testimonial', 'tadam' ),
                'add_new'             => __( 'Add New', 'tadam' ),
                'edit_item'           => __( 'Edit Item', 'tadam' ),
                'update_item'         => __( 'Update testimonial', 'tadam' ),
                'search_items'        => __( 'Search testimonial', 'tadam' ),
                'not_found'           => __( 'Not found', 'tadam' ),
                'not_found_in_trash'  => __( 'Not found in Trash', 'tadam' ),
        );
        $args = array(
                'label'               => __( 'testimonial', 'tadam' ),
               	'description'         => __( 'Testimonial Post Type', 'tadam' ),
                'labels'              => $labels,
                'supports'            => array( 'title', 'editor', 'thumbnail'),
                'hierarchical'        => false,
                'public'              => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => true,
                'show_in_admin_bar'   => true,
                'menu_position'       => 7,
        	'menu_icon'           => 'dashicons-testimonial',
                'can_export'          => true,
                'has_archive'         => true,
                'exclude_from_search' => false,
                'publicly_queryable'  => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'testimonial' ),
		'capability_type'    => 'post',
        );

        register_post_type( 'testimonial', $args );

}
endif;
add_action( 'init', 'testimonial_post_type', 0 );

if (!function_exists('cmb2_testimonial_metaboxes')):
function cmb2_testimonial_metaboxes(){
        global $tadam_vars;
        // Start with an underscore to hide fields from custom fields list
        $prefix = $tadam_vars["metaboxes_prefix"];

	/**
     	* Initiate the metabox
     	*/
    	$cmb = new_cmb2_box( array(
        	'id'            => 'tadam_testimonial_metabox',
	        'title'         => _x( 'Testimonial Data', 'admin section', 'tadam' ),
        	'object_types'  => array( 'testimonial', ), // Post type
	        'context'       => 'normal',
        	'priority'      => 'high',
	        'show_names'    => true, // Show field names on the left
        	// 'cmb_styles' => false, // false to disable the CMB stylesheet
	        // 'closed'     => true, // Keep the metabox closed by default
    	) );

	// Regular text field
    	$cmb->add_field( array(
	        'name'       => _x( 'Author name', 'admin section', 'tadam' ),
        	'desc'       => _x( "Input author's name.", 'admin section', 'tadam' ),
	        'id'         => $prefix . 'testimonial_author_name',
        	'type'       => 'text',
	        'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
        	// 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
	        // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
        	// 'on_front'        => false, // Optionally designate a field to wp-admin only
	        // 'repeatable'      => true,
    	) );

	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( 'Site name', 'admin section', 'tadam' ),
                'desc'       => _x( "Input site's name.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'testimonial_site_name',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );
	
	// Regular text field
        $cmb->add_field( array(
                'name'       => _x( 'Site url', 'admin section', 'tadam' ),
                'desc'       => _x( "Input site's url. E.g. http://www.tadam.co.il/", 'admin section', 'tadam' ),
                'id'         => $prefix . 'testimonial_site_url',
                'type'       => 'text',
                'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
                // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
                // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
                // 'on_front'        => false, // Optionally designate a field to wp-admin only
                // 'repeatable'      => true,
        ) );
}
endif;
add_action( 'cmb2_admin_init', 'cmb2_testimonial_metaboxes' );


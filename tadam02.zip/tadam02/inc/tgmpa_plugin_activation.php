<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

require_once get_template_directory() . '/inc/theme_components/TGM-Plugin-Activation-2.6.1/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'tadam_register_required_plugins' );

if (!function_exists('tadam_register_required_plugins')):
function tadam_register_required_plugins() {
	$plugins = array(
		array(
                        'name'      => 'Yoast SEO',
                        'slug'      => 'wordpress-seo',
                        'required'  => true,
                ),
		array(
                        'name'      => 'Redux Framework',
                        'slug'      => 'redux-framework',
                        'required'  => true,
                ),
		array(
                        'name'      => 'CMB2',
                        'slug'      => 'cmb2',
                        'required'  => true,
                ),
		array(
                        'name'      => 'YITH WooCommerce Compare',
                        'slug'      => 'yith-woocommerce-compare',
                        'required'  => true,
                ),
		array(
                        'name'      => 'YITH WooCommerce Quick View',
                        'slug'      => 'yith-woocommerce-quick-view',
                        'required'  => true,
                ),
		array(
                        'name'      => 'YITH WooCommerce Wishlist',
                        'slug'      => 'yith-woocommerce-wishlist',
                        'required'  => true,
                ),
		array(
                        'name'      => 'YITH WooCommerce Zoom Magnifier',
                        'slug'      => 'yith-woocommerce-zoom-magnifier',
                        'required'  => true,
                ),
		array(
                        'name'      => 'YITH WooCommerce Ajax Product Filter',
                        'slug'      => 'yith-woocommerce-ajax-navigation',
                        'required'  => true,
                ),
		array(
                        'name'      => 'YITH WooCommerce Advanced Reviews',
                        'slug'      => 'yith-woocommerce-advanced-reviews',
                        'required'  => true,
                ),
		array(
                        'name'      => 'WooCommerce Menu Cart',
                        'slug'      => 'woocommerce-menu-bar-cart',
                        'required'  => true,
                ),
	);
	$config = array(
                'id'           => 'tadam',                 // Unique ID for hashing notices for multiple instances of TGMPA.
                'default_path' => '',                      // Default absolute path to bundled plugins.
                'menu'         => 'tgmpa-install-plugins', // Menu slug.
                'has_notices'  => true,                    // Show admin notices or not.
                'dismissable'  => true,                    // If false, a user cannot dismiss the nag message.
                'dismiss_msg'  => '',                      // If 'dismissable' is false, this message will be output at top of nag.
                'is_automatic' => false,                   // Automatically activate plugins after installation or not.
                'message'      => '',                      // Message to output right before the plugins table.
	);

	tgmpa( $plugins, $config );
}
endif;

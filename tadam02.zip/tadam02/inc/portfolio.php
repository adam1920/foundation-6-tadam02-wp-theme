<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Register a Portfolio Post Type
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
if (!function_exists('portfolio_post_type')):
function portfolio_post_type() {

        $labels = array(
                'name'                => _x( 'Portfolios', 'Post Type General Name', 'tadam' ),
                'singular_name'       => _x( 'Portfolio', 'Post Type Singular Name', 'tadam' ),
                'menu_name'           => __( 'Portfolios', 'tadam' ),
                'parent_item_colon'   => __( 'Parent portfolio:', 'tadam' ),
                'all_items'           => __( 'All portfolios', 'tadam' ),
                'view_item'           => __( 'View portfolio', 'tadam' ),
                'add_new_item'        => __( 'Add New portfolio', 'tadam' ),
                'add_new'             => __( 'Add New', 'tadam' ),
                'edit_item'           => __( 'Edit Item', 'tadam' ),
                'update_item'         => __( 'Update portfolio', 'tadam' ),
                'search_items'        => __( 'Search portfolio', 'tadam' ),
                'not_found'           => __( 'Not found', 'tadam' ),
                'not_found_in_trash'  => __( 'Not found in Trash', 'tadam' ),
        );
        $args = array(
                'label'               => __( 'portfolio', 'tadam' ),
               	'description'         => __( 'Portfolio Post Type', 'tadam' ),
                'labels'              => $labels,
                'supports'            => array( 'title', 'editor', 'thumbnail'),
                'hierarchical'        => false,
                'public'              => true,
                'show_ui'             => true,
                'show_in_menu'        => true,
                'show_in_nav_menus'   => true,
                'show_in_admin_bar'   => true,
                'menu_position'       => 5,
        	'menu_icon'           => 'dashicons-carrot',
                'can_export'          => true,
                'has_archive'         => true,
                'exclude_from_search' => false,
                'publicly_queryable'  => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'portfolio' ),
		'capability_type'    => 'post',
        );

        register_post_type( 'portfolio', $args );

}
endif;
add_action( 'init', 'portfolio_post_type', 0 );

// Register Portfolio Category + Tag
if (!function_exists('create_portfolio_taxonomies')):
function create_portfolio_taxonomies() {

	// Add category
        $labels = array(
                'name'                       => _x( 'Portfolio Categories', 'Taxonomy General Name', 'tadam' ),
                'singular_name'              => _x( 'Portfolio Category', 'Taxonomy Singular Name', 'tadam' ),
                'menu_name'                  => __( 'Categories', 'tadam'),
                'all_items'                  => __( 'All Categories', 'tadam'),
                'parent_item'                => __( 'Parent Category', 'tadam' ),
                'parent_item_colon'          => __( 'Parent Category:', 'tadam' ),
                'new_item_name'              => __( 'New Category Name', 'tadam' ),
                'add_new_item'               => __( 'Add New Category', 'tadam' ),
                'edit_item'                  => __( 'Edit Category', 'tadam' ),
                'update_item'                => __( 'Update Category', 'tadam' ),
                'separate_items_with_commas' => __( 'Separate Categories with commas', 'tadam' ),
                'search_items'               => __( 'Search Categories', 'tadam' ),
                'add_or_remove_items'        => __( 'Add or remove categories', 'tadam' ),
                'choose_from_most_used'      => __( 'Choose from the most used categories', 'tadam' ),
                'not_found'                  => __( 'Not Found', 'tadam' ),
        );
        $args = array(
                'labels'                     => $labels,
                'hierarchical'               => true,
                'public'                     => true,
                'show_ui'                    => true,
                'show_admin_column'          => true,
                'show_in_nav_menus'          => true,
                'show_tagcloud'              => true,
		'rewrite' 		     => true, 
		'query_var' 		     => true
        );
        register_taxonomy( 'portfolio_category', 'portfolio', $args );

	// Add new taxonomy, NOT hierarchical (like tags)
  	$labels = array(
    		'name' => _x( 'Portfolio Tags', 'taxonomy general name', 'tadam' ),
    		'singular_name' => _x( 'Tag', 'taxonomy singular name', 'tadam' ),
    		'search_items' =>  __( 'Search Tags', 'tadam' ),
    		'popular_items' => __( 'Popular Tags', 'tadam' ),
    		'all_items' => __( 'All Tags', 'tadam' ),
    		'parent_item' => null,
    		'parent_item_colon' => null,
    		'edit_item' => __( 'Edit Tag', 'tadam' ), 
    		'update_item' => __( 'Update Tag', 'tadam' ),
    		'add_new_item' => __( 'Add New Tag', 'tadam' ),
    		'new_item_name' => __( 'New Tag Name', 'tadam' ),
    		'separate_items_with_commas' => __( 'Separate tags with commas', 'tadam' ),
    		'add_or_remove_items' => __( 'Add or remove tags', 'tadam' ),
    		'choose_from_most_used' => __( 'Choose from the most used tags', 'tadam' ),
    		'menu_name' => __( 'Tags', 'tadam' ),
  	);

	$args = array(
		'hierarchical'          => false,
		'labels'                => $labels,
		'show_ui'               => true,
		'show_admin_column'     => true,
		'update_count_callback' => '_update_post_term_count',
		'query_var'             => true,
		'rewrite'               => true,
	);

	register_taxonomy( 'portfolio_tag', 'portfolio', $args );
}
endif;
add_action( 'init', 'create_portfolio_taxonomies', 0);


if (!function_exists('cmb2_portfolio_metaboxes')):
function cmb2_portfolio_metaboxes(){
	global $tadam_vars;
	// Start with an underscore to hide fields from custom fields list
    	$prefix = $tadam_vars["metaboxes_prefix"];

    /**
     * Initiate the metabox
     */
    $cmb = new_cmb2_box( array(
        'id'            => 'tadam_portfolio_metabox',
        'title'         => _x( 'Portfolio Data', 'admin section', 'tadam' ),
        'object_types'  => array( 'portfolio', ), // Post type
        'context'       => 'normal',
        'priority'      => 'high',
        'show_names'    => true, // Show field names on the left
        // 'cmb_styles' => false, // false to disable the CMB stylesheet
        // 'closed'     => true, // Keep the metabox closed by default
    ) );

    // Regular text field
    $cmb->add_field( array(
        'name'       => _x( 'Secondary Title', 'admin section', 'tadam' ),
        'desc'       => _x( 'Portfolio secondary title', 'admin section', 'tadam' ),
        'id'         => $prefix . 'portfolio_secondary_title',
        'type'       => 'text',
        'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
        // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
        // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
        // 'on_front'        => false, // Optionally designate a field to wp-admin only
        // 'repeatable'      => true,
    ) );

	// Regular text field
    $cmb->add_field( array(
        'name'       => _x( 'Client Name', 'admin section', 'tadam' ),
        'desc'       => _x( 'The portfolio client name', 'admin section', 'tadam' ),
        'id'         => $prefix . 'portfolio_client_name',
        'type'       => 'text',
        'show_on_cb' => 'cmb2_hide_if_no_cats', // function should return a bool value
        // 'sanitization_cb' => 'my_custom_sanitization', // custom sanitization callback parameter
        // 'escape_cb'       => 'my_custom_escaping',  // custom escaping callback parameter
        // 'on_front'        => false, // Optionally designate a field to wp-admin only
        // 'repeatable'      => true,
    ) );
	
	$cmb->add_field( array(
    		'name' => _x( 'Image Gallery', 'admin section', 'tadam' ),
    		'desc' => _x( 'The portfolio image gallery', 'admin section', 'tadam' ),
    		'id'   => $prefix . 'portfolio_file_list',
    		'type' => 'file_list',
    		// 'preview_size' => array( 100, 100 ), // Default: array( 50, 50 )
    		// Optional, override default text strings
		/*
    		'text' => array(
        		'add_upload_files_text' => _x('Add or Upload Files','admin section', 'tadam'), // default: "Add or Upload Files"
        		'remove_image_text' => _x('Remove Image','admin section', 'tadam'), // default: "Remove Image"
        		'file_text' => _x('File:','admin section', 'tadam'), // default: "File:"
        		'file_download_text' => _x('Download','admin section', 'tadam'), // default: "Download"
        		'remove_text' => _x('Remove','admin section', 'tadam'), // default: "Remove"
    		),
		*/
	) );
}
endif;
add_action( 'cmb2_admin_init', 'cmb2_portfolio_metaboxes' );


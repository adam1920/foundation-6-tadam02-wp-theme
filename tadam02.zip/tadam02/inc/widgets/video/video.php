<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!class_exists('Tadam_Video')):
class Tadam_Video extends WP_Widget {
        public function __construct() {
                // widget actual processes
                parent::__construct('video', $name = _x('Tadam: Video', 'admin section', 'tadam'), array(
                        'description' => _x('Video widget.', 'admin section', 'tadam')
                ));
        }
	
	public function widget($args, $instance) {
                extract($args);

		/* User-selected settings. */
                $type = $instance['type'];
                $id = $instance['video_id'];

                // Defaults
                $defaults = $this->defaults();

                // Merge the user-selected arguments with the defaults.
                $instance = wp_parse_args( (array) $instance, $defaults );

		ob_start();

                echo $before_widget;
                if ( ! empty( $instance['title'] ) ) :
                        echo $before_title . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $after_title;
                endif;

		?>
		<div class="video-container">
                        <?php if($type == 'youtube') { ?>
	                <iframe width="100%" height="100%" src="https://www.youtube.com/embed/<?php echo $id; ?>?rel=0&amp;autohide=1&amp;showinfo=0&amp;wmode=transparent" frameborder="0" allowfullscreen></iframe>
                        <?php } elseif($type == 'vimeo') { ?>
                        <iframe src="https://player.vimeo.com/video/<?php echo $id; ?>?title=0&amp;byline=0&amp;portrait=0" width="100%" height="100%" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                        <?php } elseif($type == 'dialymotion') { ?>
                        <iframe frameborder="0" width="100%" height="100%" src="https://www.dailymotion.com/embed/video/<?php echo $id ?>?logo=0"></iframe>
                        <?php } ?>

                </div>
		<?php

                echo $after_widget;

                echo ob_get_clean();
	}

	public function update($new_instance, $old_instance) {
                // Instance
                $instance = $old_instance;

                $instance['title'] = $new_instance['title'];
                $instance['type'] = strtolower($new_instance['type']);
                $instance['video_id'] = $new_instance['video_id'];

                return $instance;
        }

	public function form($instance) {
                /* Default widget settings. */
                $defaults = $this->defaults();

                $instance = wp_parse_args( (array) $instance, $defaults );
		$types = Array(
			'youtube' 	=> _x('Youtube', 'admin section', 'tadam'),
			'vimeo' 	=> _x('Vimeo', 'admin section', 'tadam'),
			'dialymotion' 	=> _x('Dialymotion', 'admin section', 'tadam'),
		);
                ?>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:', 'tadam'); ?></label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" class="widefat" value="<?php echo esc_attr($instance['title']); ?>">
                </p>
		<p>
                        <label for="<?php echo $this->get_field_id( 'type' ); ?>"><?php _ex('Type', 'admin section', 'tadam') ?>:</label>
                        <select id="<?php echo $this->get_field_id( 'type' ); ?>" name="<?php echo $this->get_field_name( 'type' ); ?>" class="widefat">
				<?php foreach ( $types as $key => $val ): ?>
        	                        <option value="<?php echo esc_attr( $key ); ?>" <?php selected( $instance['type'], $key ); ?>><?php echo $val; ?></option>
	                        <?php endforeach; ?>
                        </select>
                </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('video_id')); ?>"><?php _ex('Video id', 'admin secton', 'tadam'); ?>:</label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('video_id')); ?>" name="<?php echo esc_attr($this->get_field_name('video_id')); ?>" class="widefat" value="<?php echo esc_attr($instance['video_id']); ?>">
                </p>
		<?php
	}

	protected function defaults(){
                return array(
                        'title'         => __('Video', 'tadam'),
                        'type'        	=> 'youtube',
                        'video_id'      => 'i3wmT2wH690',
                );
        }
}
endif;

register_widget( 'Tadam_Video' );


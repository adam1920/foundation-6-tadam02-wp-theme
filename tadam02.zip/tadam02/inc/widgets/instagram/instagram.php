<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!class_exists('Tadam_Instagram')):
class Tadam_Instagram extends WP_Widget {
        public function __construct() {
                // widget actual processes
                parent::__construct('instagram', $name = _x('Tadam: Instagram', 'admin section', 'tadam'), array(
                        'description' => _x('Show instagram embed.', 'admin section', 'tadam')
                ));
        }

	public function widget($args, $instance) {
		extract($args);

		// Defaults
                $defaults = $this->defaults();

		// Merge the user-selected arguments with the defaults.
                $instance = wp_parse_args( (array) $instance, $defaults );

		$image_id = $this->get_image_id($instance['url']);
		$hide_caption = (isset($instance['hide_caption']) && $instance['hide_caption']) ? 'true' : 'false' ;

		$url = 'https://api.instagram.com/oembed/?url=https://instagr.am/p/' . $image_id . '&maxwidth=' . $instance['width'] . '&hidecaption=' . $hide_caption;

		$args = array(
    			'timeout'     => 5,
    			'redirection' => 5,
    			'httpversion' => '1.0',
    			'user-agent'  => 'Instagram Embed',
    			'blocking'    => true,
    			'headers'     => array(),
    			'cookies'     => array(),
    			'body'        => null,
    			'compress'    => false,
    			'decompress'  => true,
    			'sslverify'   => true,
    			'stream'      => false,
    			'filename'    => null
		); 
		$result = wp_remote_get($url, $args);

                ob_start();

		echo $before_widget;
		if ( ! empty( $instance['title'] ) ) :
                        echo $before_title . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $after_title;
                endif;

		if ( $result["response"]["code"] === 200 ) {
            		$arr = (json_decode($result["body"]));
			echo $arr->html;
        	}
		echo $after_widget;

		echo ob_get_clean();
	}

	public function update($new_instance, $old_instance) {
		// Instance
                $instance = $old_instance;

                $instance['title'] = $new_instance['title'];
                $instance['url'] = $new_instance['url'];
		$instance['width'] = min ( max ( intval($new_instance['width']), 320 ), 1200 );
		$instance['hide_caption'] = ($new_instance["hide_caption"] == 'hidecaption') ? true : false;

		return $instance;
	}

	public function form($instance) {
		/* Default widget settings. */
                $defaults = $this->defaults();

                $instance = wp_parse_args( (array) $instance, $defaults );
		?>
		<p>
	                <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:', 'tadam'); ?></label>
        	        <input type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" class="widefat" value="<?php echo esc_attr($instance['title']); ?>">
	        </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('url')); ?>"><?php _e('Image URL', 'tadam'); ?>:</label>
                        <input type="url" id="<?php echo esc_attr($this->get_field_id('url')); ?>" name="<?php echo esc_attr($this->get_field_name('url')); ?>" class="widefat" value="<?php echo esc_attr($instance['url']); ?>">
                </p>
		<p>     
                        <label for="<?php echo esc_attr($this->get_field_id('width')); ?>"><?php _ex('Embed max width (px, at least 320)', 'admin section' ,'tadam'); ?>:</label>
                        <input type="number" min="320" max="1200" step="1" id="<?php echo esc_attr($this->get_field_id('width')); ?>" name="<?php echo esc_attr($this->get_field_name('width')); ?>" class="widefat" value="<?php echo esc_attr($instance['width']); ?>">
                </p>
		<p>
			<input type="checkbox" <?php checked( $instance['hide_caption'] === true ); ?> id="<?php echo $this->get_field_id( 'hide_caption' ); ?>" name="<?php echo $this->get_field_name( 'hide_caption' ); ?>" value="hidecaption">
	                <label for="<?php echo $this->get_field_id( 'hide_caption' ); ?>"><?php _ex( 'Hide Caption', 'admin section', 'tadam' ); ?></label>
		</p>
		<?php
	}
	protected function defaults(){
		return array( 
                        'title' 	=> __('Instagram', 'tadam'),
                        'url' 		=> 'https://www.instagram.com/p/BOsYaZpg3hD/',
                        'width' 	=> 600,
			'hide_caption' 	=> false
                );
	}

	protected function get_image_id($url){
		preg_match('/https?\:\/\/(?:www.)?instagram.com\/p\/(.+)\//', $url, $matches);
		return $matches[1];
	}
}
endif;
register_widget( 'Tadam_Instagram' );


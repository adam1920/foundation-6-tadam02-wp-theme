<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!class_exists('Tadam_Portfolio')):
class Tadam_Portfolio extends WP_Widget {
        public function __construct() {
                // widget actual processes
                parent::__construct('portfolio', $name = _x('Tadam: Portfolio', 'admin section', 'tadam'), array(
                        'description' => _x('Show your latest portfolio', 'admin section', 'tadam')
                ));
        }
	public function widget($args, $instance) {
                extract($args);

                // Defaults
                $defaults = $this->defaults();

                // Merge the user-selected arguments with the defaults.
                $instance = wp_parse_args( (array) $instance, $defaults );

                ob_start();

                echo $before_widget;

                if ( ! empty( $instance['title'] ) ) :
                        echo $before_title . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $after_title;
                endif;

		$portfolio_args = array('post_type' => 'portfolio', 'posts_per_page' => $instance['num_portfolio']);

                $cat_query = new WP_Query( $portfolio_args );
                if( $cat_query->have_posts() ) :
			echo '<ul class="portfolio-widget grid-widget media-list">';
        	        while ( $cat_query->have_posts() ) : $cat_query->the_post(); 
				if ( has_post_thumbnail() ) {
				?>
				<li>
					<article class="entry-item">
			                        <div class="entry-thumb"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail('half-thumbnail', array('class' => 'post-thumbnail')); ?></a></div>
        	        	                <div class="entry-content"><a href="<?php the_permalink(); ?>"><p><i class="fa fa-eye" aria-hidden="true"></i></p></a></div>
					</article>
	                        </li>
        		        <?php 
				}
			endwhile;
			echo '</ul>';
			wp_reset_postdata();
                endif;

                echo $after_widget;

                echo ob_get_clean();
        }
	
	public function update($new_instance, $old_instance) {
                $instance = $old_instance;

                $instance['title'] = $new_instance['title'];
                $instance['num_portfolio'] = abs(intval($new_instance['num_portfolio']));

                return $instance;
        }

	public function form($instance) {
                /* Default widget settings. */
                $defaults = $this->defaults();

                $instance = wp_parse_args( (array) $instance, $defaults );
                ?>
                <p>
                        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:', 'tadam'); ?></label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" class="widefat" value="<?php echo esc_attr($instance['title']); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('num_portfolio')); ?>"><?php _ex('Number of portfolio to show', 'admin section', 'tadam'); ?>:</label>
                        <input type="number" min="1" step="1" id="<?php echo esc_attr($this->get_field_id('num_portfolio')); ?>" name="<?php echo esc_attr($this->get_field_name('num_portfolio')); ?>" class="widefat" value="<?php echo esc_attr($instance['num_portfolio']); ?>">
                </p>
                <?php
        }
        protected function defaults(){
                return array(
                        'title'         => esc_html__('Recent Portfolio', 'tadam'),
			'num_portfolio'	=> 6
                );
        }

}
endif;

register_widget( 'Tadam_Portfolio' );


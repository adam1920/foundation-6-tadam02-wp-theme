<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Widget Description: Add twitter feeds on your WordPress site.
 * @see https://publish.twitter.com/
 * @see https://dev.twitter.com/web/embedded-timelines
*/

if (!class_exists('Tadam_TwitterTimeline_Widget')):
class Tadam_TwitterTimeline_Widget extends WP_Widget {
        public function __construct() {

                parent::__construct('twitter-timeline', $name = _x('Tadam: Twitter Timeline', 'admin section', 'tadam'), array(
                        'description' => _x('Display an official Twitter Embedded Timeline widget.', 'admin section', 'tadam')
                ));

                if ( is_active_widget( false, false, $this->id_base )) {
			add_action('wp_enqueue_scripts', array($this,'scripts'), 999);
                }
        }

	public function scripts(){
		wp_enqueue_script( 'twitter-widgets', '//platform.twitter.com/widgets.js', array( 'jquery' ), '1.0', true );
	}

	public function widget($args, $instance) {

		extract($args);

		// Defaults
                $defaults = $this->defaults();

                // Merge the user-selected arguments with the defaults.
                $instance = wp_parse_args( (array) $instance, $defaults );
	
		ob_start();
		
		echo $before_widget;
		if ( ! empty( $instance['title'] ) ) :
                        echo $before_title . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $after_title; 
                endif;

		echo '<a class="twitter-timeline"';

		// Data Attributes
                $data_attribs = array (
	                'width'        => 'width',
                        'height'       => 'height',
                        'tweet_limit'  => 'tweet-limit',
                        'theme'        => 'theme',
                        'link_color'   => 'link-color',
                        'border_color' => 'border-color',
                );
                foreach ( $data_attribs as $key => $val ) {
	                if ( ! empty( $instance[ $key ] ) ) {
        	                echo ' data-' . esc_attr( $val ) . '="' . esc_attr( $instance[ $key ] ) . '"';
                        }
                }

		// Chrome Settings
                if ( ! empty( $instance['chrome'] ) && is_array( $instance['chrome'] ) ) {
	                echo ' data-chrome="' . esc_attr( join ( ' ', $instance['chrome'] ) ) . '"';
                }

              	echo ' href="https://twitter.com/' . esc_attr( $instance['username'] ) . '"';


		// Close Twitter Markup
                echo '>';
                _e( 'Tweets by @', 'tadam' ) . $instance['username'];
                echo '</a>';

		echo $after_widget;

		echo ob_get_clean();
	}

	public function update($new_instance, $old_instance) {
		// Instance
                $instance = $old_instance;

		$instance['title'] = $new_instance['title'];
		$instance['username'] = $new_instance['username'];
		$instance['width'] = min ( max ( intval($new_instance['width']), 220 ), 1200 );
		$instance['height'] = max ( intval($new_instance['height']), 200 );
		$instance['tweet_limit'] = absint( $new_instance['tweet_limit'] ) ? absint( $new_instance['tweet_limit'] ) : null;

		$instance['theme'] = $new_instance['theme'];
                if ( ! in_array( $instance['theme'], array( 'light', 'dark' ) ) ) {
                        $instance['theme'] = 'light';
                }

		$instance['link_color'] = $new_instance['link_color'];
		$instance['border_color'] = $new_instance['border_color'];

		$instance['chrome'] = array();
                $chrome_settings = array(
                        'noheader',
                        'nofooter',
                        'noborders',
                        'noscrollbar',
                        'transparent'
                );
                if ( isset( $new_instance['chrome'] ) ) {
                        foreach ( $new_instance['chrome'] as $chrome ) {
                                if ( in_array( $chrome, $chrome_settings ) ) {
                                        $instance['chrome'][] = $chrome;
                                }
                        }
                }

		return $instance;
	}

	public function defaults(){
		return array(
                        'title'        => esc_html__( 'Follow me on Twitter', 'tadam' ),
                        'username'     => 'israel',
                        'width'        => '220',
                        'height'       => 400,
                        'tweet_limit'  => null,
                        'theme'        => 'light',
                        'link_color'   => '#85bcd4',
                        'border_color' => '#34748c',
                        'chrome'       => array(),
                );
	}

	public function form($instance) {
		$defaults = $this->defaults();

		$twitter_widget_theme = array (
                        'light' => _x( 'Light', 'admin section', 'tadam'),
                        'dark'  => _x( 'Dark', 'admin section', 'tadam'),
                );

		$instance = wp_parse_args( (array) $instance, $defaults );
		?>
		<p>
                        <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php _e( 'Title:', 'tadam'); ?></label>
                        <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr( $this->get_field_id( 'username' ) ); ?>"><?php _ex( 'Twitter Username', 'admin section','tadam' ); ?>:</label>
                        <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'username' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'username' ) ); ?>" value="<?php echo esc_attr( $instance['username'] ); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr( $this->get_field_id( 'width' ) ); ?>"><?php _ex( 'Maximum width (px, 220 to 1200)', 'admin section','tadam' ); ?>:</label>
                        <input type="number" min="220" max="1200" step="1" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'width' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'width' ) ); ?>" value="<?php echo esc_attr( $instance['width'] ); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr( $this->get_field_id( 'height' ) ); ?>"><?php _ex( 'Maximum height (px, at least 200)', 'admin section','tadam' ); ?>:</label>
                        <input type="number" min="200" max="" step="1" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'height' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'height' ) ); ?>" value="<?php echo esc_attr( $instance['height'] ); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr( $this->get_field_id( 'tweet_limit' ) ); ?>"><?php _ex( 'Number of Tweets Shown', 'admin section','tadam' ); ?>:</label>
                        <input type="number" min="0" max="" step="1" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tweet_limit' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tweet_limit' ) ); ?>" value="<?php echo esc_attr( $instance['tweet_limit'] ); ?>">
                </p>
		<p>
                        <label for="<?php echo $this->get_field_id( 'theme' ); ?>"><?php _ex( 'Theme', 'admin section', 'tadam' ); ?>:</label>
                        <select class="widefat" name="<?php echo $this->get_field_name( 'theme' ); ?>" id="<?php echo $this->get_field_id( 'theme' ); ?>">
              		<?php foreach ( $twitter_widget_theme as $key => $val ): ?>
                        	<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $instance['theme'], $key ); ?>><?php echo $val; ?></option>
                        <?php endforeach; ?>
	            	</select>
                </p>
		<p>
                        <label for="<?php echo esc_attr( $this->get_field_id( 'link_color' ) ); ?>"><?php _ex( 'Link color', 'admin section','tadam' ); ?>:</label>
                        <input type="color" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'link_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'link_color' ) ); ?>" value="<?php echo esc_attr( $instance['link_color'] ); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr( $this->get_field_id( 'border_color' ) ); ?>"><?php _ex( 'Border color', 'admin section','tadam' ); ?>:</label>
                        <input type="color" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'border_color' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'border_color' ) ); ?>" value="<?php echo esc_attr( $instance['border_color'] ); ?>">
                </p>
		<p>             
                        <label for="<?php echo $this->get_field_id( 'chrome' ); ?>"><?php _ex( 'Layout Options', 'admin section', 'tadam' ); ?>:</label>

                        <br />
                        <input type="checkbox" <?php checked( in_array( 'noheader', $instance['chrome'] ) ); ?> id="<?php echo $this->get_field_id( 'chrome_header' ); ?>" name="<?php echo $this->get_field_name( 'chrome' ); ?>[]" value="noheader" />
                        <label for="<?php echo $this->get_field_id( 'chrome_header' ); ?>"><?php _ex( 'No Header', 'admin section', 'tadam' ); ?></label>

                        <br />
                        <input type="checkbox" <?php checked( in_array( 'nofooter', $instance['chrome'] ) ); ?> id="<?php echo $this->get_field_id( 'chrome_footer' ); ?>" name="<?php echo $this->get_field_name( 'chrome' ); ?>[]" value="nofooter" />
                        <label for="<?php echo $this->get_field_id( 'chrome_footer' ); ?>"><?php _ex( 'No Footer', 'admin section', 'tadam' ); ?></label>

                        <br />  
                        <input type="checkbox" <?php checked( in_array( 'noborders', $instance['chrome'] ) ); ?> id="<?php echo $this->get_field_id( 'chrome_border' ); ?>" name="<?php echo $this->get_field_name( 'chrome' ); ?>[]" value="noborders" />
                        <label for="<?php echo $this->get_field_id( 'chrome_border' ); ?>"><?php _ex( 'No Borders', 'admin section', 'tadam' ); ?></label>

                        <br />
                        <input type="checkbox" <?php checked( in_array( 'noscrollbar', $instance['chrome'] ) ); ?> id="<?php echo $this->get_field_id( 'chrome_scrollbar' ); ?>" name="<?php echo $this->get_field_name( 'chrome' ); ?>[]" value="noscrollbar" />
                        <label for="<?php echo $this->get_field_id( 'chrome_scrollbar' ); ?>"><?php _ex( 'No Scrollbar', 'admin action', 'tadam' ); ?></label>

                        <br />  
                        <input type="checkbox" <?php checked( in_array( 'transparent', $instance['chrome'] ) ); ?> id="<?php echo $this->get_field_id( 'chrome_transparent' ); ?>" name="<?php echo $this->get_field_name( 'chrome' ); ?>[]" value="transparent" />
                        <label for="<?php echo $this->get_field_id( 'chrome_transparent' ); ?>"><?php _ex( 'Transparent Background', 'admin action', 'tadam' ); ?></label>
                </p>
		<?php
	}
}
endif;
register_widget( 'Tadam_TwitterTimeline_Widget' );


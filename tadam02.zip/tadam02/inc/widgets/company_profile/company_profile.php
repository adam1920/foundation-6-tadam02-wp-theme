<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!class_exists('Tadam_Company_Profile')):
class Tadam_Company_Profile extends WP_Widget {
        public function __construct() {
                // widget actual processes
                parent::__construct('company-profile', $name = _x('Tadam: Company Profile', 'admin section', 'tadam'), array(
                        'description' => _x('Display info about your company. Such as logo, text & address', 'admin section', 'tadam')
                ));
        }

        public function widget($args, $instance) {

                extract($args);

                $logo_url = $instance['logo_url'];
                $title = $instance['title'];
                $free_text = $instance['free_text'];
                $address =  $instance['address'] ;
                $phone = $instance['phone'] ;
                $email =  $instance['email'] ;

                echo $before_widget;
                        echo '<div class="about-wrap">';
			echo '<header class="widget-header">';			
			if ( !empty ( $instance['logo_url'] ) ){
				printf('<div class="logo"><a href="%s"><img alt="%s" src="%s"></a></div>' , esc_url( home_url() ), get_bloginfo( 'name' ), esc_url( $instance['logo_url'] ));
			}
			if ( !empty ( $instance['title'] ) ){
				printf('<h3 class="widget-title">%s</h3>', esc_attr( $instance['title'] ));
			}
			echo '</header>';

			echo '<div class="widget-content">';
			if ( !empty ( $instance['free_text'] ) ) {
                                printf( '<p>%s</p>', esc_attr( $instance['free_text'] ) );
                        }
                        if ( !empty ( $instance['address'] ) || !empty ( $instance['phone'] ) || !empty ( $instance['email'] )){
                                echo '<ul class="contact">';
                                        if ( !empty ( $instance['address'] ) ) {
                                                printf( '<li class="address"><i class="fa fa-map-marker"></i> %s</li>', esc_attr( $instance['address'] ) );
                                        }
                                        if ( !empty ( $instance['phone'] ) ) {
                                                printf( '<li class="phone"><i class="fa fa-phone"></i> <a href="callto:%s">%s</a></li>', esc_attr( $instance['phone'] ), esc_attr( $instance['phone'] ) );
                                        }
                                        if ( !empty ( $instance['email'] ) ) {
                                                printf('<li class="email"><i class="fa fa-envelope"></i> <a href="mailto:%s">%s</a></li>', antispambot(esc_attr( $instance['email'] )), antispambot(esc_attr( $instance['email'])));
                                        }
                                echo '</ul>';
                        }
			echo '</div><!-- /.widget-content -->';
                        echo '</div><!-- /.about-wrap -->';
                echo $after_widget;
        }

        public function update($new_instance, $old_instance) {
		$instance = $old_instance;

                $instance['logo_url'] = $new_instance['logo_url'] ;
                $instance['title'] =  $new_instance['title'] ;
                $instance['free_text'] =  $new_instance['free_text'] ;
                $instance['address'] =  $new_instance['address'] ;
                $instance['phone'] = $new_instance['phone'] ;
                $instance['email'] =  $new_instance['email'] ;
                return $instance;
        }
        public function form($instance) {
		global $tadam_vars;

                /* Default widget settings. */
                $defaults = array(
                        'logo_url' => $tadam_vars["customize"]["default_footer_logo"],
                        'title' => __('We are creative studio since 2000', 'tadam'),
                        'free_text' => __('We\'ve worked on hundreds of websites. Contact us and lets talk about your project.', 'tadam'),
                        'address' => __('Zihron Yakov, Israel', 'tadam'),
                        'phone' => '077-5356264',
                        'email' => 'support@tadam.co.il',
                );

                $instance = wp_parse_args( (array) $instance, $defaults );

        ?>

        <p>
                <label for="<?php echo esc_attr($this->get_field_id('logo_url')); ?>"><?php _ex('Logo URL', 'admin section', 'tadam'); ?>:</label>
		<input type="text" id="<?php echo esc_attr($this->get_field_id('logo_url')); ?>" name="<?php echo esc_attr($this->get_field_name('logo_url')); ?>" value="<?php echo esc_attr($instance['logo_url']); ?>" class="widefat" >
        </p>
	<p>
                <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:', 'tadam'); ?></label>
                <input type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" class="widefat" value="<?php echo esc_attr($instance['title']); ?>">
        </p>
        <p>
                <label for="<?php echo esc_attr($this->get_field_id('free_text')); ?>"><?php _ex('Short text about the site', 'admin section' ,'tadam'); ?>:</label>
                <textarea id="<?php echo esc_attr($this->get_field_id('free_text')); ?>" name="<?php echo esc_attr($this->get_field_name('free_text')); ?>" class="widefat" ><?php echo esc_attr($instance['free_text']); ?></textarea>
        </p>
        <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'address' )); ?>"><?php _e('Address', 'tadam'); ?>:</label>
                <input id="<?php echo esc_attr($this->get_field_id( 'address' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'address' )); ?>" value="<?php echo esc_attr($instance['address']); ?>" class="widefat" type="text">
        </p>
        <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'phone' )); ?>"><?php _ex('Phone', 'admin section', 'tadam'); ?>:</label>
                <input id="<?php echo esc_attr($this->get_field_id( 'phone' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'phone' )); ?>" value="<?php echo esc_attr($instance['phone']); ?>" class="widefat" type="text">
        </p>
        <p>
                <label for="<?php echo esc_attr($this->get_field_id( 'email' )); ?>"><?php _e('Email', 'tadam'); ?>:</label>
                <input id="<?php echo esc_attr($this->get_field_id( 'email' )); ?>" name="<?php echo esc_attr($this->get_field_name( 'email' )); ?>" value="<?php echo esc_attr($instance['email']); ?>" class="widefat" type="text">
        </p>
        <?php
        }
}
endif;
register_widget( 'Tadam_Company_Profile' );



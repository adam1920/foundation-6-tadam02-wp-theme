<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!class_exists('Tadam_Facebook_Page_Plugin')):
class Tadam_Facebook_Page_Plugin extends WP_Widget {
        public function __construct() {
                // widget actual processes
                parent::__construct('facebook_page_plugin', $name = _x('Tadam: Facebook Fans Page', 'admin section', 'tadam'), array(
                        'description' => _x('Facebook Page Plugin', 'admin section', 'tadam')
                ));

		if ( is_active_widget( false, false, $this->id_base ) ) {
			add_action('body_begin', array($this,'js_sdk'));
                }
        }

	public function widget($args, $instance) {
                extract($args);

                // Defaults
                $defaults = $this->defaults();

                // Merge the user-selected arguments with the defaults.
                $instance = wp_parse_args( (array) $instance, $defaults );

		// ini
		$page_url = esc_url($instance['page_url']);
	
		ob_start();

                echo $before_widget;
                if ( ! empty( $instance['title'] ) ) :
                        echo $before_title . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $after_title;
                endif;
		?>
		<div class="fb-page" 
		data-href="<?php echo $page_url; ?>" 
		data-tabs="<?php echo esc_attr($instance['tabs']); ?>" 
		data-width="<?php echo esc_attr($instance['width']); ?>" 
		data-height="<?php echo esc_attr($instance['height']); ?>" 
		data-small-header="<?php echo esc_attr($instance['small_header']); ?>" 
		data-adapt-container-width="<?php echo esc_attr($instance['adapt_container_width']); ?>" 
		data-hide-cover="<?php echo esc_attr($instance['hide_cover']); ?>" 
		data-show-facepile="<?php echo esc_attr($instance['show_facepile']); ?>">
		<blockquote cite="<?php echo $page_url; ?>" class="fb-xfbml-parse-ignore"><a href="<?php echo $page_url; ?>"><?php echo $instance['page_title']; ?></a></blockquote>
		</div>	
		<?php
                echo $after_widget;

                echo ob_get_clean();
	}
	
	public function update($new_instance, $old_instance) {
                // Instance
                $instance = $old_instance;

                $instance['title'] = $new_instance['title'];
                $instance['page_title'] = $new_instance['page_title'];
                $instance['page_url'] = $new_instance['page_url'];
                $instance['tabs'] = $new_instance['tabs'];
		$instance['width'] = min ( max ( intval($new_instance['width']), 180 ), 500 );
		$instance['height'] = max ( intval($new_instance['height']), 70 );
		$instance['small_header'] = ($new_instance["small_header"] == 'small_header') ? true : false;
		$instance['hide_cover'] = ($new_instance["hide_cover"] == 'hide_cover') ? true : false;
		$instance['adapt_container_width'] = ($new_instance["adapt_container_width"] == 'adapt_container_width') ? true : false;
		$instance['show_facepile'] = ($new_instance["show_facepile"] == 'show_facepile') ? true : false;

                return $instance;
        }
	
	public function form($instance) {
                /* Default widget settings. */
                $defaults = $this->defaults();

                $instance = wp_parse_args( (array) $instance, $defaults );
                ?>
                <p>
                        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _ex('Widget Title', 'admin section', 'tadam'); ?>:</label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" class="widefat" value="<?php echo esc_attr($instance['title']); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('page_title')); ?>"><?php _ex('Facebook Page Title', 'admin section', 'tadam'); ?>:</label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('page_title')); ?>" name="<?php echo esc_attr($this->get_field_name('page_title')); ?>" class="widefat" value="<?php echo esc_attr($instance['page_title']); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('page_url')); ?>"><?php _ex('Facebook Page URL','admin section','tadam'); ?>:</label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('page_url')); ?>" name="<?php echo esc_attr($this->get_field_name('page_url')); ?>" class="widefat" value="<?php echo esc_attr($instance['page_url']); ?>" placeholder="<?php echo esc_attr_x('The URL of the Facebook page','admin section','tadam'); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('tabs')); ?>"><?php _ex('Tabs','admin section', 'tadam'); ?>:</label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('tabs')); ?>" name="<?php echo esc_attr($this->get_field_name('tabs')); ?>" class="widefat" value="<?php echo esc_attr($instance['tabs']); ?>" placeholder="<?php echo esc_attr_x('e.g., timeline, messages, events','admin section','tadam'); ?>">
			<small><?php _ex('Tabs to render i.e. <em>timeline, events, messages</em>. Use a comma-separated list to add multiple tabs, i.e. <em>timeline, events</em>','admin section','tadam'); ?></small>
                </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('width')); ?>"><?php _e('Width', 'tadam'); ?>:</label>
                        <input type="number" min="180" max="500" step="1" id="<?php echo esc_attr($this->get_field_id('width')); ?>" name="<?php echo esc_attr($this->get_field_name('width')); ?>" class="widefat" value="<?php echo esc_attr($instance['width']); ?>" placeholder="<?php echo esc_attr_x('The pixel width of the embed (Min. 180 to Max. 500)','admin section','tadam'); ?>">
                        <small><?php _ex('The pixel width of the embed (Min. 180 to Max. 500)','admin section','tadam'); ?></small>			
                </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('height')); ?>"><?php _e('Height', 'tadam'); ?>:</label>
                        <input type="number" min="70" step="1" id="<?php echo esc_attr($this->get_field_id('height')); ?>" name="<?php echo esc_attr($this->get_field_name('height')); ?>" class="widefat" value="<?php echo esc_attr($instance['height']); ?>" placeholder="<?php echo esc_attr_x('The pixel height of the embed (Min. 70)','admin section','tadam'); ?>">
                        <small><?php _ex('The pixel height of the embed (Min. 70)','admin section','tadam'); ?></small>
                </p>
		<p>
                        <input type="checkbox" <?php checked( $instance['small_header'] === true ); ?> id="<?php echo $this->get_field_id( 'small_header' ); ?>" name="<?php echo $this->get_field_name( 'small_header' ); ?>" value="small_header">
                        <label for="<?php echo $this->get_field_id( 'small_header' ); ?>"><?php _ex( 'Small Header', 'admin section', 'tadam' ); ?></label>
                </p>
		<p>
                        <input type="checkbox" <?php checked( $instance['hide_cover'] === true ); ?> id="<?php echo $this->get_field_id( 'hide_cover' ); ?>" name="<?php echo $this->get_field_name( 'hide_cover' ); ?>" value="hide_cover">
                        <label for="<?php echo $this->get_field_id( 'hide_cover' ); ?>"><?php _ex( 'Hide Cover', 'admin section', 'tadam' ); ?></label>
                </p>
		<p>
                        <input type="checkbox" <?php checked( $instance['adapt_container_width'] === true ); ?> id="<?php echo $this->get_field_id( 'adapt_container_width' ); ?>" name="<?php echo $this->get_field_name( 'adapt_container_width' ); ?>" value="adapt_container_width">
                        <label for="<?php echo $this->get_field_id( 'adapt_container_width' ); ?>"><?php _ex( 'Adapt to plugin container width', 'admin section', 'tadam' ); ?></label>
                </p>
		<p>
                        <input type="checkbox" <?php checked( $instance['show_facepile'] === true ); ?> id="<?php echo $this->get_field_id( 'show_facepile' ); ?>" name="<?php echo $this->get_field_name( 'show_facepile' ); ?>" value="show_facepile">
                        <label for="<?php echo $this->get_field_id( 'show_facepile' ); ?>"><?php _ex( 'Show Friend\'s Faces', 'admin section', 'tadam' ); ?></label>
                </p>
		<?php
	}

	protected function defaults(){
                return array(
                        'title'         => esc_html__('Facebook Fans Page', 'tadam'),
                        'page_title'    => esc_html__('United With Israel', 'tadam'),
                        'page_url'     	=> 'https://www.facebook.com/unitedwithisrael/',
			'tabs'		=> 'timeline',
			'width'		=> 340,
			'height'	=> 500,
			'small_header'	=> false,
			'hide_cover'	=> false,
			'adapt_container_width'	=> true,
			'show_facepile'	=> true,
                );
        }

	public function js_sdk(){
		ob_start();
		?>
		<div id="fb-root"></div>
		<script>(function(d, s, id) {
		  var js, fjs = d.getElementsByTagName(s)[0];
		  if (d.getElementById(id)) return;
		  js = d.createElement(s); js.id = id;
		  js.src = "//connect.facebook.net/<?php echo get_locale(); ?>/sdk.js#xfbml=1&version=v2.8&appId=100591450050015";
		  fjs.parentNode.insertBefore(js, fjs);
		}(document, 'script', 'facebook-jssdk'));</script>
		<?php
		echo ob_get_clean();
	}

}
endif;

register_widget( 'Tadam_Facebook_Page_Plugin' );


<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!class_exists('Tadam_Feedburner')):
class Tadam_Feedburner extends WP_Widget {
        public function __construct() {
                // widget actual processes
                parent::__construct('feedburner', $name = _x('Tadam: Newsletters', 'admin section', 'tadam'), array(
                        'description' => _x('Subscribe to feedburner via email', 'admin section', 'tadam')
                ));
        }

	public function widget($args, $instance) {
                extract($args);

                // Defaults
                $defaults = $this->defaults();

                // Merge the user-selected arguments with the defaults.
                $instance = wp_parse_args( (array) $instance, $defaults );

		// ini
		$feedburner = $instance['feedburner_id'];

		ob_start();

		echo $before_widget;
                if ( ! empty( $instance['title'] ) ) :
                        echo $before_title . apply_filters( 'widget_title',  $instance['title'], $instance, $this->id_base ) . $after_title;
                endif;

		?>
		<form id="newsletters" action="http://feedburner.google.com/fb/a/mailverify" method="post" target="popupwindow" onsubmit="window.open('http://feedburner.google.com/fb/a/mailverify?uri=<?php echo $feedburner ; ?>', 'popupwindow', 'scrollbars=yes,width=550,height=520');return true">
			<input type="hidden" value="<?php echo $feedburner ; ?>" name="uri">
                        <input type="hidden" name="loc" value="<?php echo get_locale(); ?>">
			<div class="input-group">
				<span class="input-group-label"><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
  				<input class="input-group-field" type="text" placeholder="<?php esc_attr_e( 'Enter your e-mail address' , 'tadam') ; ?>">
  				<div class="input-group-button"><button class="button" type="submit" title="<?php esc_attr_e('Send', 'tadam');?>"><i class="fa fa-paper-plane" aria-hidden="true"></i></button></div>
			</div>
			
                </form>
		<?php

		echo $after_widget;

                echo ob_get_clean();
	}

	public function update($new_instance, $old_instance) {
                // Instance
                $instance = $old_instance;

                $instance['title'] = $new_instance['title'];
                $instance['feedburner_id'] = $new_instance['feedburner_id'];

                return $instance;
        }

	public function form($instance) {
                /* Default widget settings. */
                $defaults = $this->defaults();

                $instance = wp_parse_args( (array) $instance, $defaults );
                ?>
                <p>
                        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php _e('Title:', 'tadam'); ?></label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" class="widefat" value="<?php echo esc_attr($instance['title']); ?>">
                </p>
		<p>
                        <label for="<?php echo esc_attr($this->get_field_id('feedburner_id')); ?>"><?php _ex('Feedburner id:', 'admin section', 'tadam'); ?></label>
                        <input type="text" id="<?php echo esc_attr($this->get_field_id('feedburner_id')); ?>" name="<?php echo esc_attr($this->get_field_name('feedburner_id')); ?>" class="widefat" value="<?php echo esc_attr($instance['feedburner_id']); ?>">
                </p>
	<?php
        }
        protected function defaults(){
                return array(
                        'title'         => esc_html__('Subscribe to Our Newsletters', 'tadam'),
                        'feedburner_id' => '',
                );
        }	
}
endif;

register_widget( 'Tadam_Feedburner' );


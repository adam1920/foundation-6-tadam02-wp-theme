<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function get_blog_cover_image(){
	global $tadam_vars;

	if (get_the_post_thumbnail_url(get_option('page_for_posts'), 'tadam-featured-image')){
		return get_the_post_thumbnail_url(get_option('page_for_posts'), 'tadam-featured-image');
	}
	return get_theme_mod('blog_cover_image', $tadam_vars["customize"]["default_blog_cover_image"]);
}

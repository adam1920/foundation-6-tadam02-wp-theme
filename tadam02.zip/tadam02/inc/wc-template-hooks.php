<?php
/**
 * WooCommerce Tadam Template Hooks
 *
 * Action/filter hooks used for WooCommerce functions/templates.
*/

if ( ! defined( 'ABSPATH' ) ) {
        exit; // Exit if accessed directly
}

add_action( 'woocommerce_before_main_content', array('WC_Tadam', 'woocommerce_output_content_wrapper'), 5 );
add_action( 'woocommerce_after_main_content', array('WC_Tadam', 'woocommerce_output_content_wrapper_end'), 20 );
add_action( 'woocommerce_sidebar', array('WC_Tadam', 'woocommerce_sidebar_wrapper'), 5 );
add_action( 'woocommerce_sidebar', array('WC_Tadam', 'woocommerce_sidebar_wrapper_end'), 20 );
add_action( 'woocommerce_before_add_to_cart_button', array('WC_Tadam', 'woocommerce_output_add_to_cart_button'), 10 );
add_action( 'woocommerce_after_add_to_cart_button', array('WC_Tadam', 'woocommerce_output_add_to_cart_button_end'), 10 );
add_action( 'woocommerce_single_product_summary', array('WC_Tadam', 'woocommerce_output_single_product_summary'), 70 );
add_action( 'woocommerce_single_product_summary', 'tadam_social_share', 80 );
add_action( 'woocommerce_single_product_summary', array('WC_Tadam', 'woocommerce_output_single_product_summary_end'), 90 );

// hooks in content-product.php
add_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_close', 15 );

add_action( 'tadam_woocommerce_before_shop_loop_item_title', array('WC_Tadam', 'woocommerce_template_loop_product_thumbnail_wrapper'), 5 );
add_action( 'tadam_woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 4 );
add_action( 'tadam_woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_open', 7 );
add_action( 'tadam_woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
add_action( 'tadam_woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 15 );


add_action( 'tadam_woocommerce_before_shop_loop_item_title', array('WC_Tadam', 'woocommerce_template_loop_product_box_hover'), 20 );
add_action( 'tadam_woocommerce_before_shop_loop_item_title', array('WC_Tadam', 'woocommerce_template_loop_product_thumbnail_wrapper_end'), 100 );

add_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_link_open', 5 );
add_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_link_close', 20 );

add_action( 'tadam_woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );




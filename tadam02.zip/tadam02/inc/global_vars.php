<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!isset($tadam_vars["direction"])){
	if (is_rtl()){
		$tadam_vars["direction"] = Array ("text-direction" => 'right', 'default-float' => 'right', 'opposite-direction' => 'left');
	}else{
		$tadam_vars["direction"] = Array ("text-direction" => 'left', 'default-float' => 'left', 'opposite-direction' => 'right');
	}
}
if (!isset($tadam_vars["metaboxes_prefix"])){
	$tadam_vars["metaboxes_prefix"] = '_tadam_';
}
if (!isset($tadam_vars["metaboxes_prefix_page_types"])){
        $tadam_vars["metaboxes_prefix_page_types"] = '_tadam_page_types_';
}
if (!isset($tadam_vars["metaboxes_prefix_post_types"])){
        $tadam_vars["metaboxes_prefix_post_types"] = '_tadam_post_types_';
}

if (!isset($tadam_vars["social_arr"])){
	// Construct sharing URL without using any script
	$tadam_vars["social_arr"]["twitter"] 		= Array('class' => 'fa fa-twitter tadam-twitter');
	$tadam_vars["social_arr"]["facebook"] 		= Array('class'=>'fa fa-facebook tadam-facebook');
	$tadam_vars["social_arr"]["google_plus"] 	= Array('class' => 'fa fa-google-plus tadam-googleplus');
	$tadam_vars["social_arr"]["whatsapp"] 		= Array('class' => 'fa fa-whatsapp tadam-whatsapp');
	$tadam_vars["social_arr"]["linkedin"] 		= Array('class' => 'fa fa-linkedin tadam-linkedin');
	$tadam_vars["social_arr"]["pinterest"] 		= Array('class' => 'fa fa-pinterest-p tadam-pinterest');
	$tadam_vars["social_arr"]["github"] 		= Array('class' => 'fa fa-github tadam-github');
}

if (!isset($tadam_vars["customize"])){

	// footer
	$tadam_vars["customize"]["default_footer_logo"] = get_parent_theme_file_uri('/assets/images/logo-footer.png');

}

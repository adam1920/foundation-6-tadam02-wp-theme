<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tadam functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/ 
 * @link https://developer.wordpress.org/reference/functions/add_theme_support/ 
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 1.0
 */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function tadamtheme_setup() {
	global $tadam_vars;

	/*
         * Make theme available for translation.
         * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/tadam02
         */
	load_theme_textdomain( 'tadam', get_template_directory() .'/languages' );

        // Add default posts and comments RSS feed links to head.
        add_theme_support( 'automatic-feed-links' );

        /*
         * Let WordPress manage the document title.
         * By adding theme support, we declare that this theme does not use a
         * hard-coded <title> tag in the document head, and expect WordPress to
         * provide it for us.
         */
        add_theme_support( 'title-tag' );

	/*
         * Enable support for Post Thumbnails on posts and pages.
         *
         * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
        */
	add_theme_support( 'post-thumbnails', array( 'post', 'page', 'portfolio', 'our_team') );

	add_image_size( 'tadam-featured-image', 2000, 1200, true );
	add_image_size( 'tadam-cover-image', 2000, 500, true );
	add_image_size( 'tadam-isotope-grid', 355, 355, true );

	/*
	* Enable support for yoast seo breadcrumbs
	*/
	add_theme_support( 'yoast-seo-breadcrumbs' );


	// This theme uses wp_nav_menu() in three locations.
        register_nav_menus( array(
                'topbar-menu'    => _x( 'Top Bar Menu', 'admin section', 'tadam' ),
                'drill-menu' 	=> _x( 'Drill Menu', 'admin section' ,'tadam' ),
                'social-menu' 	=> _x( 'Social Links Menu', 'admin section' ,'tadam' ),
        ) );	

	/*
         * Switch default core markup for search form, comment form, and comments
         * to output valid HTML5.
         */
        add_theme_support( 'html5', array(
                'comment-form',
                'comment-list',
                'gallery',
                'caption',
        ) );

        /*
         * Enable support for Post Formats.
         *
         * See: https://codex.wordpress.org/Post_Formats
         */
        add_theme_support( 'post-formats', array(
                'aside',
                'image',
                'video',
                'quote',
                'link',
                'gallery',
                'audio',
        ) );

	// Add theme support for selective refresh for widgets.
        add_theme_support( 'customize-selective-refresh-widgets' );

	// Define and register starter content to showcase the theme on new sites.
        $starter_content = array(
                'widgets' => array(
			'sidebar-main' => array(
				'text_business_info',
                                'search',
                                'text_about',
			),
			'sidebar-faq' => array(
				'text_business_info',
			),
			'sidebar-testimonial' => array(
				'text_business_info',
			),
                        'footer-one' => array(
                                'Tadam_Company_Profile',
                        ),
                        'footer-two' => array(
                                'Tadam_Flickr',
                        ),
                        'footer-three' => array(
				'recent-posts'
                        ),
			'footer-four' => array(
                                'Tadam_Instagram',
                        ),
                ),
		// Specify the core-defined pages to create and add custom thumbnails to some of them.
                'posts' => array(
                        'home',
                ),
		// Default to a static front page and assign the front and posts pages.
                'options' => array(
                        'show_on_front' 	=> 'page',
                        'page_on_front' 	=> '{{home}}',
                        'page_for_posts' 	=> '{{blog}}',
                ),
		// Set up nav menus for each of the two areas registered in the theme.
                'nav_menus' => array(
                        // Assign a menu to the "top" location.
                        'top' => array(
                                'name' => _x( 'Top Menu', 'admin section', 'tadam' ),
                                'items' => array(
                                        'link_home', // Note that the core "home" page is actually a link in case a static front page is not used.
                                        'page_about',
                                        'page_blog',
                                        'page_contact',
                                ),
                        ),

                        // Assign a menu to the "social" location.
                        'social' => array(
                                'name' => _x( 'Social Links Menu', 'admin section', 'tadam' ),
                                'items' => array(
                                        'link_facebook',
                                        'link_twitter',
                                        'link_instagram',
                                        'link_email',
                                ),
                        ),
                ),
	);

	/**
         * Filters Tadam array of starter content.
         *
         * @since Tadam_01
         *
         * @param array $starter_content Array of starter content.
         */
        $starter_content = apply_filters( 'tadam_starter_content', $starter_content );

        add_theme_support( 'starter-content', $starter_content );

	
	/*
         * This theme styles the visual editor to resemble the theme style,
         * specifically font, colors, and column width.
         */
       	add_editor_style('assets/css/editor-style.css');

}
add_action( 'after_setup_theme', 'tadamtheme_setup' );

/*
 * Declare WooCommerce support 
 * DOCS: https://docs.woocommerce.com/document/third-party-custom-theme-compatibility/?utm_source=notice&utm_medium=product&utm_content=themecompatibility&utm_campaign=woocommerceplugin
*/
add_action( 'after_setup_theme', 'woocommerce_support' );
function woocommerce_support() {
    add_theme_support( 'woocommerce' );
}

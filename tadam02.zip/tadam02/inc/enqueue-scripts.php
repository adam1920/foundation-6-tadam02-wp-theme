<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Disable WooCommerce's Default Stylesheets
function disable_woocommerce_default_css( $styles ) {

        // Disable the stylesheets below via unset():
        unset( $styles['woocommerce-general'] );  // Styling of buttons, dropdowns, etc.
        // unset( $styles['woocommerce-layout'] );        // Layout for columns, positioning.
        // unset( $styles['woocommerce-smallscreen'] );   // Responsive design for mobile devices.

        return $styles;
}
add_action('woocommerce_enqueue_styles', 'disable_woocommerce_default_css');

function site_scripts() {
	global $tadam_vars;

	// Register main stylesheet
	if (is_rtl()){
		// array('woocommerce-general', 'woocommerce-layout', 'woocommerce-smallscreen')
		wp_enqueue_style( 'site-css', get_template_directory_uri() . '/dist/css/app-rtl.css', array('woocommerce-layout', 'woocommerce-smallscreen'), '1.0.0', 'all' );
	}else{
	    	wp_enqueue_style( 'site-css', get_template_directory_uri() . '/dist/css/app.css', array('woocommerce-layout', 'woocommerce-smallscreen'), '1.0.0', 'all' );
	}


	// Adding scripts file in the footer
	wp_enqueue_script( 'site-js', get_template_directory_uri() . '/dist/js/all.js', array( 'jquery' ), '1.0.0', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
                wp_enqueue_script( 'comment-reply' );
        }

}
add_action('wp_enqueue_scripts', 'site_scripts', 999);

// wp_head hook
function tadam_hook_css() {
	global $tadam_options;
	echo '<style>';

	if ($tadam_options["header-layout"] === 'logo_right_menu_left'){
	?>
		.site-header .top-bar{
			flex-direction: row-reverse;
		}
		.site-header .top-bar .site-title-container{
			text-align:right;
		}
		[dir=rtl] .site-header .top-bar .site-title-wrapper{
                        text-align:left;
                }
	<?
	}
	if ($tadam_options["single-page-layout"] === 'sidebar-left'){
	?>
		body.page.page-template-default #content > .row{
			flex-direction: row-reverse;
		}
	<?php
	}
	if ($tadam_options["single-post-layout"] === 'sidebar-left'){
        ?>
                body.single.single_post #content > .row{
                        flex-direction: row-reverse;
                }
        <?php
        }
	if ($tadam_options["archive-post-layout"] === 'sidebar-left'){
	?>
		body.archive.category #content > .row{
                        flex-direction: row-reverse;
                }
	<?php
	}
	echo '</style>';	
}
add_action('wp_head', 'tadam_hook_css');

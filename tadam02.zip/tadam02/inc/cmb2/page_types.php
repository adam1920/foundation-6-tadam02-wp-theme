<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!function_exists('cmb2_page_types_metaboxes')):
function cmb2_page_types_metaboxes(){
        global $tadam_vars, $wpdb;
        // Start with an underscore to hide fields from custom fields list
        $prefix = $tadam_vars["metaboxes_prefix_page_types"];

	/**
     	* Initiate the metabox
     	*/
    	$cmb = new_cmb2_box( array(
        	'id'            => 'tadam_page_types_metabox',
	        'title'         => _x( 'Page Options', 'admin section', 'tadam' ),
        	'object_types'  => array( 'page' ), // Post type
	        'context'       => 'normal',
        	'priority'      => 'high',
	        'show_names'    => true, // Show field names on the left
        	// 'cmb_styles' => false, // false to disable the CMB stylesheet
	        // 'closed'     => true, // Keep the metabox closed by default
    	) );

	$cmb->add_field( array(
                'name'       => _x( 'Enable Blank Page:', 'admin section', 'tadam' ),
                'desc'       => _x( "No Header, No Footer - Just Primary Content", 'admin section', 'tadam' ),
                'id'         => $prefix . 'blank_page',
                'type'       => 'checkbox',
        ) );

	$cmb->add_field( array(
                'name'	=> _x( 'Title Bar', 'admin section', 'tadam' ),
		'type'	=> 'title',
		'id'	=> $prefix . 'title-bar-title'
	) );

	// get layer sliders list
        $table = $wpdb->prefix.LS_DB_TABLE;
        // Make the call
        $list = $wpdb->get_results("SELECT * FROM $table WHERE flag_hidden = '0' AND flag_deleted = '0' ORDER BY date_c ASC LIMIT 100");
	$result = Array();
	if ($list){
		foreach ($list as $row){
			$result[$row->id] = $row->name;
		}
	}

	$cmb->add_field( array(
                'name'       => _x( 'Layer Slider:', 'admin section', 'tadam' ),
                'id'         => $prefix . 'layer-slider',
                'type'       => 'select',
		'show_option_none' => true,
                'options'          => $result,
        ) );
}
endif;
add_action( 'cmb2_admin_init', 'cmb2_page_types_metaboxes' );



<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!function_exists('cmb2_all_types_metaboxes')):
function cmb2_all_types_metaboxes(){
        global $tadam_vars;
        // Start with an underscore to hide fields from custom fields list
        $prefix = $tadam_vars["metaboxes_prefix"];

	/**
     	* Initiate the metabox
     	*/
    	$cmb = new_cmb2_box( array(
        	'id'            => 'tadam_all_types_metabox',
	        'title'         => _x( 'Advanced Options', 'admin section', 'tadam' ),
        	'object_types'  => array( 'page', 'post', 'testimonial', 'portfolio', 'faq', 'our_team' ), // Post type
	        'context'       => 'normal',
        	'priority'      => 'high',
	        'show_names'    => true, // Show field names on the left
        	// 'cmb_styles' => false, // false to disable the CMB stylesheet
	        // 'closed'     => true, // Keep the metabox closed by default
    	) );

    	$cmb->add_field( array(
	        'name'       => _x( 'Page Title:', 'admin section', 'tadam' ),
        	'desc'       => _x( "If you want to Hide/Show the Page Title.", 'admin section', 'tadam' ),
	        'id'         => $prefix . 'page_title',
        	'type'       => 'select',
		'default'	=> 'default',
		'options'          => array(
			'default' 	=> esc_html_x( 'Default', 'admin section', 'tadam' ),
			'show'   	=> esc_html_x( 'Show', 'admin section', 'tadam' ),
			'hide'     	=> esc_html_x( 'Hide', 'admin section', 'tadam' ),
		),
    	) );
	$cmb->add_field( array( 
                'name'       => _x( 'Breadcrumbs:', 'admin section', 'tadam' ),
                'desc'       => _x( "If you want to Hide/Show the Breadcrumbs.", 'admin section', 'tadam' ),
                'id'         => $prefix . 'breadcrumbs',
                'type'       => 'select',
		'default'       => 'default',
                'options'          => array(
                        'default'       => esc_html_x( 'Default', 'admin section', 'tadam' ),
                        'show'          => esc_html_x( 'Show', 'admin section', 'tadam' ),
                        'hide'          => esc_html_x( 'Hide', 'admin section', 'tadam' ),
                ),
        ) );
}
endif;
add_action( 'cmb2_admin_init', 'cmb2_all_types_metaboxes' );


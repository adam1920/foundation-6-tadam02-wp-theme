<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Tadam: Customizer
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 */

/**
 * Add postMessage support for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */

/**
 * Implement the Custom Header feature.
 */
require get_parent_theme_file_path( '/inc/customizer/custom-header.php' );

if (!function_exists('tadam_sanitize_opacity')):
function tadam_sanitize_opacity( $input ){
	if ($input >= 0 && $input <= 1){
		return $input;
	}
	return 0.9;
}
endif;

if (!function_exists('tadam_sanitize_load_twitter_script')):
function tadam_sanitize_load_twitter_script($input){
	$valid = array( 'yes', 'no' );

        if ( in_array( $input, $valid ) ) {
                return $input;
        }

        return 'yes';
} 
endif;


<?php
/**
 * The template for displaying our team taxonomy department page
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();
?>
<div class="row">
        <div class="columns large-9">
        <div id="primary" class="content-area">
                <main id="main" class="site-main" role="main">
			<header class="entry-header">
                                <h1 class="entry-title"><?php tadam_wp_title(); ?></h1>
                        </header>
                <?php
                // get all our team members
                $our_team_args = array(
			'post_type' => 'our_team', 
			'suppress_filters' => get_option('suppress_filters'), 
			'nopaging' => 1, 
			'tax_query' => array(
                        	array(
                                	'taxonomy' => 'our_team_department',
                                        'field'    => 'id',
                                        'terms'    => get_queried_object()->term_id,
                                ),
                ));
                $query = new WP_Query( $our_team_args );

                if ( $query->have_posts()) : ?>
                        <div class="tadam-isotope-grid">
                        <?php
                        /* Start the Loop */
                        while ( $query->have_posts() ) : $query->the_post();

                                /*
                                 * Include the Post-Format-specific template for the content.
                                 * If you want to override this in a child theme, then include a file
                                 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                                 */
                                get_template_part( 'template-parts/our_team/content', 'grid-item' );

                        endwhile;
                        ?>
                        </div>
                        <?php wp_reset_postdata();
                else :

                        get_template_part( 'template-parts/our_team/content', 'none' );

                endif; ?>

                </main><!-- #main -->
        </div><!-- #primary -->

        </div><!-- /.columns -->

	<div class="columns large-3">
		<?php
		// get categories
		$categories = get_categories(Array('taxonomy' => 'our_team_department'));
		if ($categories):
		?>
			<ul class="menu vertical docs-nav">
				<li class="docs-nav-title"><?php _e('Our Team Departments', 'tadam'); ?></li>
		<?php
			foreach ($categories as $category){
			?>
				<li class="<?php echo ($category->term_id === get_queried_object()->term_id) ? 'current' : ''; ?>"><a href="<?php echo get_term_link($category); ?>"><?php echo $category->name; ?></a></li>
			<?php
			}
		?>
			</ul>
		<?php endif;?>
	</div>
</div><!-- .row -->

<?php get_footer();



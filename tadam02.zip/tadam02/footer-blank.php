<?php
/**
 * The template for displaying the footer
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars, $tadam_options;

?>

</div><!-- /#content -->
</div><!-- /.site-content-contain -->


</div><!-- /#page -->
<?php wp_footer(); ?>
</body>
</html>


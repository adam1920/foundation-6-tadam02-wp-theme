<?php
/**
 * The template for displaying portfolio archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); 

// get categories
$categories = get_categories(Array('taxonomy' => 'portfolio_category'));
?>

<div class="row">
        <div class="columns">
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main">
			<header class="entry-header">
				<h1 class="entry-title"><?php tadam_wp_title(); ?></h1>
			</header>
		<?php
		if ($categories){
		?>
		<div class="tadam-isotope-filters button-group js-radio-button-group">
        		<button data-filter="*" class="button is-checked"><?php _e('Show all', 'tadam'); ?></button>
        		<?php
                	foreach ($categories as $category){
                	?>
                       		<button data-filter=".<?php echo $category->slug; ?>" class="button"><?php echo $category->name; ?></button>
                	<?php
                	}        		
        		?>
		</div>
		<?php
		}
		?>

		<?php
		// get all portfolios
		$portfolio_args = array('post_type' => 'portfolio', 'suppress_filters' => get_option('suppress_filters'), 'nopaging' => 1);
		$query = new WP_Query( $portfolio_args );

		if ( $query->have_posts()) : ?>
			<div class="tadam-isotope-grid">
			<?php
			/* Start the Loop */
			while ( $query->have_posts() ) : $query->the_post();

				/*
				 * Include the Post-Format-specific template for the content.
				 * If you want to override this in a child theme, then include a file
				 * called content-___.php (where ___ is the Post Format name) and that will be used instead.
				 */
				get_template_part( 'template-parts/portfolio/content', 'grid-item' );

			endwhile;
			?>
			</div>
			<?php wp_reset_postdata();
		else :

			get_template_part( 'template-parts/portfolio/content', 'none' );

		endif; ?>

		</main><!-- #main -->
	</div><!-- #primary -->

        </div><!-- /.columns -->

</div><!-- .row -->

<?php get_footer();



<?php
/**
 * The template for displaying testimonial single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
global $tadam_vars;

get_header(); ?>

<div class="row">
	<div class="columns large-8 medium-12 small-12">

        <div id="primary" class="content-area">
                <main id="main" class="site-main" role="main">
			<header class="entry-header">
        			<?php the_title( '<h1 class="entry-title">', '</h1>' );?>
			</header>
                        <?php
                                /* Start the Loop */
                                while ( have_posts() ) : the_post();

                                        get_template_part( 'template-parts/testimonial/content', get_post_format() );

					get_template_part( 'template-parts/post/comments');

                                        the_post_navigation( array(
                                                'prev_text' => '<span class="screen-reader-text">' . __( 'Previous Post', 'tadam' ) . '</span><span aria-hidden="true" class="nav-subtitle">' . __( 'Previous', 'tadam' ) . '</span> <span class="nav-title"><span class="nav-title-icon-wrapper">' . tadam_get_svg( array( 'icon' => 'arrow-left' ) ) . '</span>%title</span>',
                                                'next_text' => '<span class="screen-reader-text">' . __( 'Next Post', 'tadam' ) . '</span><span aria-hidden="true" class="nav-subtitle">' . __( 'Next', 'tadam' ) . '</span> <span class="nav-title">%title<span class="nav-title-icon-wrapper">' . tadam_get_svg( array( 'icon' => 'arrow-right' ) ) . '</span></span>',
                                        ) );

                                endwhile; // End of the loop.
                        ?>

                </main><!-- #main -->
        </div><!-- #primary -->

	</div><!-- /.columns -->
	
	<div class="columns large-4 medium-12 small-12">
	        <?php get_sidebar('testimonial'); ?>
	</div><!-- /.columns -->
</div><!-- .row -->

<?php get_footer();


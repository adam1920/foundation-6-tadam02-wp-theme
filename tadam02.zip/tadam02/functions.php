<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// For use with some settings
// DOC: https://codex.wordpress.org/Function_Reference/wp_get_theme
$my_theme = wp_get_theme();

// Global vars (put this file first!!)
require_once get_parent_theme_file_path('/inc/global_vars.php');

// Register scripts and stylesheets
require_once get_parent_theme_file_path('/inc/enqueue-scripts.php');
// Register wp_footer scripts
require_once get_parent_theme_file_path('/inc/wp_footer-scripts.php');

// Custimization
require_once get_parent_theme_file_path('/inc/customizer/customizer.php');

// Plugable functions
require_once get_parent_theme_file_path('/inc/plugable.php');

// Shortcodes
require_once get_parent_theme_file_path('/inc/shortcodes/social_menu.php');
require_once get_parent_theme_file_path('/inc/shortcodes/user.php');
require_once get_parent_theme_file_path('/inc/shortcodes/social_share.php');

// Widgets
require_once get_parent_theme_file_path('/inc/widgets/company_profile/company_profile.php');
require_once get_parent_theme_file_path('/inc/widgets/twitter/twitter.php');
require_once get_parent_theme_file_path('/inc/widgets/instagram/instagram.php');
require_once get_parent_theme_file_path('/inc/widgets/video/video.php');
require_once get_parent_theme_file_path('/inc/widgets/facebook_page_plugin/facebook_page_plugin.php');
require_once get_parent_theme_file_path('/inc/widgets/feedburner/feedburner.php');
require_once get_parent_theme_file_path('/inc/widgets/portfolio/portfolio.php');

// Sidebars
require_once get_parent_theme_file_path('/inc/sidebars.php');

// Add theme support
require_once get_parent_theme_file_path('/inc/theme-support.php');

// icon functions
require_once get_parent_theme_file_path('/inc/icon-functions.php');

// excerpt more
require_once get_parent_theme_file_path('/inc/excerpt_more.php');

// Custom post types
require_once get_parent_theme_file_path('/inc/portfolio.php');
require_once get_parent_theme_file_path('/inc/faq.php');
require_once get_parent_theme_file_path('/inc/testimonial.php');
require_once get_parent_theme_file_path('/inc/our_team.php');

// Plugins recommendations
require_once get_parent_theme_file_path('/inc/tgmpa_plugin_activation.php');

// CMB2 advanced options
require_once get_parent_theme_file_path('/inc/cmb2/all_types.php');
require_once get_parent_theme_file_path('/inc/cmb2/page_types.php');

// Menu walkers
require_once get_parent_theme_file_path('/inc/theme_components/foundation-6-wordpress-menu-walkers/foundation-6-drill-menu-walker-class.php');
require_once get_parent_theme_file_path('/inc/theme_components/foundation-6-wordpress-menu-walkers/foundation-6-topbar-menu-walker-class.php');

// Additional features to allow styling of the templates.
require_once get_parent_theme_file_path( '/inc/template-functions.php' );

// header custom media functions 
require_once get_parent_theme_file_path( 'inc/header-custom-media-functions.php');

// Enable shortcodes in text widgets
add_filter('widget_text','do_shortcode');

// Add custom image size
add_image_size( 'half-thumbnail', 75, 75, true );

// add custom hooks
if (!function_exists('body_begin')):
	function body_begin() {
        	do_action('body_begin');
	}
endif;

// Custom template tags for this theme.
require_once get_parent_theme_file_path( '/inc/template-tags.php' );

/**
 * Use front-page.php when Front page displays is set to a static page.
 *
 * @since Tadam_O1
 *
 * @param string $template front-page.php.
 *
 * @return string The template to be used: blank if is_home() is true (defaults to index.php), else $template.
 */
function tadam_front_page_template( $template ) {
        return is_home() ? '' : $template;
}
add_filter( 'frontpage_template',  'tadam_front_page_template' );

/**
 * Set the content width based on the theme's design and stylesheet.
 *
 * @since Tadam_01 0.1 
 */
if ( ! isset( $content_width ) ) {
        $content_width = 1170;
}

// Redux framework
include( get_stylesheet_directory() . '/inc/redux-framework/config.php');

// Woocommerce
include( get_parent_theme_file_path() . '/inc/wc-template-hooks.php' );
include( get_parent_theme_file_path() . '/inc/classes/WC_Tadam.php' );
include( get_parent_theme_file_path() . '/inc/wc-template-functions.php' );
include( get_parent_theme_file_path() . '/inc/wc-product-video-tab.php' );

// Template hooks
include( get_parent_theme_file_path() . '/inc/template-hooks.php');



<?php
/**
 * Displays content for front page
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'tadam-panel ' ); ?> >

	<div class="panel-content">
		<div class="row">
			<div class="columns">

			<div class="entry-content">
				<?php
					/* translators: %s: Name of current post */
					the_content( sprintf(
						__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'tadam' ),
						get_the_title()
					) );
				?>
				<?php tadam_edit_link( get_the_ID() ); ?>
			</div><!-- .entry-content -->

			</div>
		</div><!-- .row -->
	</div><!-- .panel-content -->

</article><!-- #post-## -->

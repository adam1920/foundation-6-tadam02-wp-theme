<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php 
	if (!is_front_page()):
	?>
	<header class="entry-header">
                <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
                <?php tadam_edit_link( get_the_ID() ); ?>
        </header><!-- .entry-header -->
	<?php
	endif;
	?>
	<div class="entry-content">
		<?php
			the_content();

			wp_link_pages( array(
                                'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'tadam' ) . '</span>',
                                'after'       => '</div>',
                                'link_before' => '<span class="page-number">',
                                'link_after'  => '</span>',
                                'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>%',
                                'separator'   => '<span class="screen-reader-text">, </span>',
                        ) );
		?>
	</div><!-- .entry-content -->
</article><!-- #post-## -->

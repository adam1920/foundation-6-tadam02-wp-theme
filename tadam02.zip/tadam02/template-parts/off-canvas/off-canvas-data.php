<?php
/**
 * Displays off-canvas
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars, $tadam_options;

?>
<button class="close-button" aria-label="<?php esc_attr_e('Close menu', 'tadam'); ?>" type="button" data-close><span aria-hidden="true">&times;</span></button>


<div class="site-branding">
	<div class="site-branding-text">
               	<p class="site-title logo-title text-center"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><img src="<?php echo esc_url($tadam_options["off-canvas-logo"]["url"]); ?>" alt="<?php bloginfo('name'); ?>" width="<?php echo esc_attr($tadam_options["off-canvas-logo"]["width"]); ?>" height="<?php echo esc_attr($tadam_options["off-canvas-logo"]["height"]); ?>"></a></p>
		<?php
		/*
                $description = get_bloginfo( 'description', 'display' );
                if ( $description || is_customize_preview() ) : ?>
                	<p class="site-description text-center"><?php echo $description; ?></p>
                <?php endif; 
		*/
		?>
        </div><!-- .site-branding-text -->
</div><!-- .site-branding -->

<?php get_template_part( 'template-parts/navigation/navigation', 'drill' ); ?>

<div class="links-list-wrapper clearfix">
	<div class="float-left"><?php echo tadam_user(); ?></div>
	<div class="float-right"><?php echo tadam_social_menu(); ?></div>
</div>

<?php get_search_form(); 

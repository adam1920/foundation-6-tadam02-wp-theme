<?php
/**
 * Displays drill menu
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( has_nav_menu( 'drill-menu' ) ) : ?>
        <div class="navigation-offcanvas">
	<?php
	echo wp_nav_menu(array(
	        'container' => false,
        	'menu' => _x( 'Drill Menu', 'admin section', 'tadam' ),
	        'menu_class' => 'vertical menu',
        	'theme_location' => 'drill-menu',
	        'items_wrap'      => '<ul id="%1$s" class="%2$s" data-drilldown="">%3$s</ul>',
        	//Recommend setting this to false, but if you need a fallback...
	        'fallback_cb' => 'f6_drill_menu_fallback',
	    	'walker' => new F6_DRILL_MENU_WALKER(),
	));
	?>
        </div><!-- /.navigation-offcanvas -->
<?php endif;



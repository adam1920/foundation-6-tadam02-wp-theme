<?php
/**
 * Displays top navigation
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( has_nav_menu( 'topbar-menu' ) ) : ?>
	<div class="navigation-top text-center">
	<?php echo wp_nav_menu(array(
	        'container' => false,
        	'menu' => _x( 'Top Bar Menu', 'admin section', 'tadam' ),
	        'menu_class' => 'dropdown menu flex-container',
        	'theme_location' => 'topbar-menu',
	        'items_wrap'      => '<ul id="%1$s" class="%2$s" data-dropdown-menu>%3$s</ul>',
        	//Recommend setting this to false, but if you need a fallback...
	        'fallback_cb' => 'f6_topbar_menu_fallback',
        	'walker' => new F6_TOPBAR_MENU_WALKER(),
	));?>
        </div><!-- .navigation-top -->
<?php endif;

<?php
/**
 * Displays header multi buttons
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_options;

?>
<ul class="multi-btn-menu tadam-list-menu <?php echo (is_rtl() || $tadam_options["header-layout"] === 'logo_right_menu_left') ? 'float-left' : 'float-right' ; ?>">
	<?php echo tadam_user(false, "show-for-large"); ?>
	<li><a class="search-btn slide-down"><i class="fa fa-search" aria-hidden="true"></i></a></li>
	<li class="hide-for-large"><a id="offCanvasOpenButton" data-toggle="offCanvas"><i class="fa fa-bars" aria-hidden="true"></i></a></li>	
	<li class="show-for-medium"><a href="#content" class="menu-scroll-down"><i class="arrow fa fa-arrow-down" aria-hidden="true"></i></a></li>
</ul>

<?php
/**
 * Template part for displaying portfolio meta block
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars;
?>
<div class="block-meta row">
	<div class="columns large-4">
        	<h4 class="title"><?php _e('Date', 'tadam'); ?></h4>
                <p><span class="fa fa-ellipsis-h">&nbsp;&nbsp;</span><?php the_date(); ?></p>
        </div>
        <div class="columns large-4">
                <h4 class="title"><?php _e('Client', 'tadam'); ?></h4>
                <p><span class="fa fa-ellipsis-h">&nbsp;&nbsp;</span><?php echo get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'portfolio_client_name', true); ?></p>
	</div>
        <div class="columns large-4">
                <h4 class="title"><?php _e('Project Type', 'tadam'); ?></h4>
                <p><span class="fa fa-ellipsis-h">&nbsp;&nbsp;</span><?php echo get_the_term_list(get_the_ID(), 'portfolio_category', '', ', ', ''); ?></p>
        </div>
</div>

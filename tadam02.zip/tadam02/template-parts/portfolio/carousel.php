<?php
/**
 * Template part for displaying portfolio images carousel
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars;
$sliders = get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'portfolio_file_list', true);
if ($sliders):
?>
<div class="orbit" role="region" aria-label="<?php echo esc_attr(get_the_title()); ?>" data-orbit>
  <ul class="orbit-container">

    <button class="orbit-previous"><span class="show-for-sr"><?php _e('Previous Slide', 'tadam') ?></span>&#9664;&#xFE0E;</button>
    <button class="orbit-next"><span class="show-for-sr"><?php _e('Next Slide', 'tadam') ?></span>&#9654;&#xFE0E;</button>
	<?php
	foreach ($sliders as $image_id => $image_url){
		$attachment = wp_get_attachment($image_id);
	?>
		<li class="is-active orbit-slide">
      			<img class="orbit-image" src="<?php echo esc_url($image_url);?>" alt="<?php echo esc_attr($attachment["alt"]); ?>">
			<?php 
			if ($attachment["caption"]){
			?>
	      			<figcaption class="orbit-caption"><?php echo esc_attr($attachment["caption"]); ?></figcaption>
			<?php
			}
			?>
    		</li>
	<?php
	}
	?>
  </ul>
  <nav class="orbit-bullets">
    <button class="is-active" data-slide="0"><span class="show-for-sr"><?php echo _e('First slide details.','tadam'); ?></span><span class="show-for-sr"><?php echo _e('Current Slide','tadam'); ?></span></button>
	<?php
	for ($i=1, $len=count($sliders); $i<$len; $i++){
	?> 
		<button data-slide="<?php echo $i; ?>"><span class="show-for-sr"><?php echo sprintf( __( '%s slide details.','tadam' ), $i );?></span></button>
	<?php
	}	
	?>
  </nav>
</div>
<?php endif;

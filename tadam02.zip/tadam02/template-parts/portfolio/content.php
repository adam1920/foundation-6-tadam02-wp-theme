<?php
/**
 * Template part for displaying portfolio content
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
        <div class="entry-content">
                <?php
                /* translators: %s: Name of current post */
                the_content( sprintf(
                        __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'tadam' ),
                        get_the_title()
                ) );

		wp_link_pages( array(
                                'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'tadam' ) . '</span>',
                                'after'       => '</div>',
                                'link_before' => '<span class="page-number">',
                                'link_after'  => '</span>',
                                'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>%',
                                'separator'   => '<span class="screen-reader-text">, </span>',
                ) );
                ?>
        </div><!-- .entry-content -->
</article>


<?php 
/**
 * Template part for displaying portfolio header
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars;
?>
<header class="entry-header">
	<?php the_title( '<h1 class="entry-title">', '</h1>' );?>
	<p class="sub-title"><?php echo get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'portfolio_secondary_title', true); ?></p>
</header>

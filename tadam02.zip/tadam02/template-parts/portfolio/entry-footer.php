<?php
/**
 * Template part for displaying portfolio entry footer
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<footer class="entry-footer">
<div class="block-social row">
        <div class="columns large-6">
		<?php tadam_social_share(); ?>
        </div>
        <div class="columns large-6 tagclouds-links <?php echo is_rtl() ? 'text-left' : 'text-right'; ?>">
                <span class="label"><?php _e('Tags', 'tadam'); ?>:</span>
        	<?php echo get_the_term_list(get_the_ID(), 'portfolio_tag', '', ', ', ''); ?>
	</div>
</div>
</footer>
<?php if ( is_single() ) : ?>
        <?php tadam_edit_link(); ?>
<?php endif; 

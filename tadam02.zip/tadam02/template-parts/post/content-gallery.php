<?php
/**
 * Template part for displaying gallery posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<?php
	if ( is_sticky() && is_home() ) :
		echo tadam_get_svg( array( 'icon' => 'thumb-tack' ) );
	endif;
	?>

	<?php if ( '' !== get_the_post_thumbnail() && ! is_single() && ! get_post_gallery() ) : ?>
                <div class="post-thumbnail">
                        <a href="<?php the_permalink(); ?>" class="image-link">
                                <?php the_post_thumbnail( 'large'); ?>
				<div class="overlay-image"></div>
                                <div class="overlay-title"><i class="fa fa-plus"></i></div>
                        </a>
                </div><!-- .post-thumbnail -->
        <?php endif; ?>

	<header class="entry-header">
		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );	?>
	</header><!-- .entry-header -->

	<div class="entry-content">

		<?php if ( ! is_single() ) :

			// If not a single post, highlight the gallery.
                        if ( get_post_gallery() ) :
                                echo '<div class="entry-gallery">';
                                        echo get_post_gallery();
                                echo '</div>';
                        endif;

		endif;

		if ( is_single() || ! get_post_gallery() ) :

			/* translators: %s: Name of current post */
                        the_content( sprintf(
                                __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'tadam' ),
                                get_the_title()
                        ) );

			wp_link_pages( array(
                                'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'tadam' ) . '</span>',
                                'after'       => '</div>',
                                'link_before' => '<span class="page-number">',
                                'link_after'  => '</span>',
                                'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>%',
                                'separator'   => '<span class="screen-reader-text">, </span>',
                        ) );
		endif; ?>

	</div><!-- .entry-content -->

	<?php if ( 'post' === get_post_type() ) :
                                echo '<div class="entry-meta">';
                                        if ( is_single() ) :
                                                tadam_posted_on();
                                        else :
                                                echo tadam_time_link();
                                                tadam_edit_link();
                                        endif;
                                echo '</div><!-- .entry-meta -->';
        endif;
	?>

</article><!-- #post-## -->

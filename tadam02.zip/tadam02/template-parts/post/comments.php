<?php
/**
 * Template part for displaying comments
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_options, $tadam_vars;

// If comments are open or we have at least one comment, load up the comment template.
if ( (comments_open() || get_comments_number()) && ($tadam_options["comments"] === 'show' && get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix"] . 'comments', true ) !== 'hide' || get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix"] . 'comments', true ) === 'show') ) :
	comments_template();
endif;

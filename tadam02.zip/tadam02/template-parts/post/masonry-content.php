<?php
/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
global $tadam_vars, $tadam_options;

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( Array('masonry-wrapper') ); ?>>
	<?php
	if ( is_sticky() && is_home() ) :
		echo tadam_get_svg( array( 'icon' => 'thumb-tack' ) );
	endif;
	?>

	<?php if ( '' !== get_the_post_thumbnail() && ! is_single() ) : ?>
                <div class="post-thumbnail">
                        <a href="<?php the_permalink(); ?>" class="image-link">
                                <?php the_post_thumbnail( 'large' ); ?>
				<div class="overlay-image"></div>
				<div class="overlay-title"><i class="fa fa-plus"></i></div>
                        </a>
                </div><!-- .post-thumbnail -->
        <?php endif; ?>


	<div class="media-body">

	<header class="entry-header">
		<?php the_title( '<h2 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );	?>
	</header><!-- .entry-header -->

	<div class="entry-content">
		
		<?php
		if ($tadam_options["archive-content"] === 'excerpt'):
		?>
			<div class="entry-excerpt">
       		                <p><?php echo wp_trim_words( get_the_excerpt(), $tadam_options["archive-excerpt-length"] ); ?></p>
                	</div>

			<div class="row">
				<div class="columns small-6 text-<?php echo $tadam_vars["direction"]["text-direction"] ?>">
					<?php
					        if ( 'post' === get_post_type() ) :
				                	echo '<div class="entry-meta">';
			                       		echo tadam_time_link();
			                       		tadam_edit_link();
				                	echo '</div><!-- .entry-meta -->';
					        endif;
				        ?>
				</div>
				<div class="columns small-6 text-<?php echo $tadam_vars["direction"]["opposite-direction"] ?>">
					<?php if ($tadam_options["archive-read-more"] === 'show'): ?>
				                <a href="<?php the_permalink(); ?>" class="read-more"><?php echo $tadam_options["archive-read-more-text"]; ?></a>
					<?php endif; ?>
				</div>
			</div>

		<?php else: 
			/* translators: %s: Name of current post */
                        the_content( sprintf(
                                __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'tadam' ),
                                get_the_title()
                        ) );
		endif;
		?>

		<?php
			wp_link_pages( array(
                                'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'tadam' ) . '</span>',
                                'after'       => '</div>',
                                'link_before' => '<span class="page-number">',
                                'link_after'  => '</span>',
                                'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>%',
                                'separator'   => '<span class="screen-reader-text">, </span>',
                        ) );
		?>
	</div><!-- .entry-content -->

	<?php
	if ( 'post' === get_post_type() && $tadam_options["archive-content"] !== 'excerpt') :
                echo '<div class="entry-meta">';
         	       echo tadam_time_link();
                       tadam_edit_link();
	        echo '</div><!-- .entry-meta -->';
        endif;	
	?>
	</div><!-- /.media-body -->
</article><!-- #post-## -->

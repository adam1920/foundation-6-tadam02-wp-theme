<?php
/**
 * Template part for displaying testimonial posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-content">
		<div class="media-object">
  			<div class="media-object-section">
				<?php if ( '' !== get_the_post_thumbnail() ) : ?>
			                <div class="post-thumbnail">
						<?php
						if (is_single()){
							 the_post_thumbnail( 'thumbnail', array('class'=>'thumbnail') );
						}else{
						?>
	                        			<a href="<?php the_permalink(); ?>" class="thumbnail">
				                                <?php the_post_thumbnail( 'thumbnail' ); ?>
                	        			</a>
						<?php
						}
						?>
			                </div><!-- .post-thumbnail -->
			        <?php endif; ?>
  			</div>
  			<div class="media-object-section">
				<?php if (!is_single()) : ?>
				<header class="entry-header">
			                <?php the_title( '<h4 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark"><q>', '</q></a></h4>' ); ?>
			        </header><!-- .entry-header -->
				<?php endif; ?>
				<blockquote>
				<?php
                	        /* translators: %s: Name of current post */
                        	the_content( sprintf(
	                                __( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'tadam' ),
        	                        get_the_title()
                	        ) );
		                ?>
				</blockquote>
  			</div>
		</div><!-- /.media-object -->
		<p><cite><?php echo get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'testimonial_author_name', true); ?> | <a href="<?php echo htmlspecialchars(get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'testimonial_site_url', true)); ?>"><?php echo get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'testimonial_site_name', true); ?></a></cite></p>

		<?php
			wp_link_pages( array(
                                'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'tadam' ) . '</span>',
                                'after'       => '</div>',
                                'link_before' => '<span class="page-number">',
                                'link_after'  => '</span>',
                                'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>%',
                                'separator'   => '<span class="screen-reader-text">, </span>',
                        ) );
		?>
	</div><!-- .entry-content -->
	<?php if ( is_single() ) : ?>
		<?php tadam_entry_footer(); ?>
        <?php endif; ?>

</article><!-- #post-## -->



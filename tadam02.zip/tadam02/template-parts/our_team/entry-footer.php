<?php
/**
 * Template part for displaying our team entry footer
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars;

/* social */
$is_has_social = false;
if (get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_facebook_url', true)){
        $tadam_vars["social_arr"]["facebook"]["url"] = get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_facebook_url', true);
        $is_has_social = true;
}
if (get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_twitter_url', true)){
        $tadam_vars["social_arr"]["twitter"]["url"] = get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_twitter_url', true);
        $is_has_social = true;
}
if (get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_googleplus_url', true)){
        $tadam_vars["social_arr"]["google_plus"]["url"] = get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_googleplus_url', true);
        $is_has_social = true;
}
if (get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_linkedin_url', true)){
        $tadam_vars["social_arr"]["linkedin"]["url"] = get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_linkedin_url', true);
        $is_has_social = true;
}
if (get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_github_url', true)){
        $tadam_vars["social_arr"]["github"]["url"] = get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_github_url', true);
        $is_has_social = true;
}

?>
<footer class="entry-footer">
<div class="block-social row">
	<?php
	if ($tadam_vars["social_arr"]):
	?>
        <div class="columns large-6">
		<?php
                                if ($is_has_social):
                                ?>
                                        <ul class="social-share-links">
						<li><span class="label"><?php _e('Folow me', 'tadam');?>:</span></li>
                                                <?php foreach($tadam_vars["social_arr"] as $key => $item){
                                                        if (!isset($item["url"]) || !isset($item["class"])) continue;
                                                ?>
                                                        <li><a target="blank" href="<?php echo $item["url"]; ?>" class="badge <?php echo $item["class"]; ?>"><span class="screen-reader-text"><?php echo $key; ?></span></a></li>
                                                <?php
                                                }
                                                ?>
                                        </ul>
                                <?php
                                endif;
                                ?>

        </div>
	<?php endif; ?>
        <div class="columns large-6 tagclouds-links <?php echo is_rtl() ? 'text-left' : 'text-right'; ?>">
                <span class="label"><?php _e('Department', 'tadam'); ?>:</span>
        	<?php echo get_the_term_list(get_the_ID(), 'our_team_department', '', ', ', ''); ?>
	</div>
</div>
</footer>
<?php if ( is_single() ) : ?>
        <?php tadam_edit_link(); ?>
<?php endif; ?>

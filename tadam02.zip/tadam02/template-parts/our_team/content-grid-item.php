<?php
/**
 * Template part for displaying our team grid item
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars;
$grid_class = Array();
if($terms = get_the_terms(get_the_ID(), 'our_team_department')){
	foreach ($terms as $term){
		array_push($grid_class, $term->slug);
	}
};
?>
<div class="grid-item <?php echo implode(' ', $grid_class); ?>">
	<div class="entry-thumb zoom">
		<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>">
			<?php
		        if ( has_post_thumbnail() ) :
		                the_post_thumbnail( 'tadam-isotope-grid' );
			else:
			?>
				<img src="//placehold.it/355" alt="">
			<?php
                        endif;
                        ?>
		</a>
		<p><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><i aria-hidden="true" class="fa fa-link"></i></a></p>
	</div>
        <div class="entry-content">
		<h4 class="entry-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
		<p><?php echo get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_position', true); ?></p>
	</div>
</div>

<?php
/**
 * Template part for displaying our team member posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<div class="entry-content">

		<div class="row">
			<div class="columns large-5 text-center">
				<?php 
				if ( has_post_thumbnail() ) :
	                                the_post_thumbnail( 'tadam-isotope-grid', array('class' => 'thumbnail') );
				endif;
				?>

				<?php
				if (get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_phone', true) || get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_email', true)){
				?>
				<address class="contact-info">
					<ul class="menu vertical text-center">
						<?php
						if (get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_phone', true)){
						?>
							<li><a href="tel:<?php echo get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_phone', true); ?>"><i class="fa fa-phone" aria-hidden="true"></i> <?php echo get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_phone', true); ?></a></li>
						<?php
						}
						if (get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_email', true)){
                                                ?>
                                                        <li><a href="mailto:<?php echo antispambot(get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_email', true)); ?>"><i class="fa fa-envelope-o" aria-hidden="true"></i> <?php echo antispambot(get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_email', true)); ?></a></li>
                                                <?php
                                                }
						?>						
					</ul>
				</address>
				<?php
				}
				?>
			</div>
			<div class="columns large-7">
				<header class="entry-header">
					<p class="entry-title"><?php echo get_post_meta(get_the_ID(), $tadam_vars["metaboxes_prefix"].'our_team_member_position', true); ?></p>
                                </header><!-- .entry-header -->
				<?php the_content();  ?>
			</div>
		</div>

		<?php
			wp_link_pages( array(
                                'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'tadam' ) . '</span>',
                                'after'       => '</div>',
                                'link_before' => '<span class="page-number">',
                                'link_after'  => '</span>',
                                'pagelink'    => '<span class="screen-reader-text">' . __( 'Page', 'tadam' ) . ' </span>%',
                                'separator'   => '<span class="screen-reader-text">, </span>',
                        ) );
		?>
	</div><!-- .entry-content -->
</article><!-- #post-## -->



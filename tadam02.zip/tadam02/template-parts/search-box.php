<div class="search-box">
	<button class="close-button" aria-label="<?php esc_attr_e('Close search box', 'tadam'); ?>" type="button"></button>
	<?php get_search_form(); ?>
</div>

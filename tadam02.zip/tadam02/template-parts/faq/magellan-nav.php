<?php
/**
 * Magelan navigation for faq list
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<?php
$terms = get_terms( array(
    	'taxonomy' 	=> 'faq_tag',
    	'hide_empty' 	=> true,
	'order'		=> 'ASC'
) );

if ($terms):
?>
	<nav class="columns sticky" data-sticky data-sticky-on="large" data-anchor="primary">
	<ul class="vertical menu docs-nav" data-magellan>
	<?php
	foreach ($terms as $term){
	?>
		<li><a href="#faq-section-<?php echo $term->slug; ?>"><?php echo $term->name ?></a></li>
	<?php
	}
	?>
	</ul>
	</nav>
<?php endif;

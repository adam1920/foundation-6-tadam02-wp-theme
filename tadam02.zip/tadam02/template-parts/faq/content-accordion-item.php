<?php
/**
 * Accordion item
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>

<li class="accordion-item post-<?php the_ID(); ?>" data-accordion-item>
        <a href="#" class="accordion-title"><?php the_title(); ?></a>
        <div class="accordion-content" data-tab-content>
        	<?php the_content(); ?>
	</div>
</li>

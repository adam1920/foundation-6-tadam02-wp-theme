<?php
/**
 * Displays header site branding
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars, $tadam_options;

?>
<?php if ( is_front_page() ) : ?>
	<h1 class="site-title logo-title">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
		<?php if($tadam_options["header-logo"]["url"]): ?>
			<img src="<?php echo esc_url($tadam_options["header-logo"]["url"]); ?>" class="custom-logo" alt="" itemprop="logo" data-attachment-id="<?php echo esc_attr($tadam_options["header-logo"]["id"]); ?>" data-permalink="<?php echo esc_url(wp_get_attachment_url( $tadam_options["header-logo"]["id"] )); ?>" width="<?php echo esc_attr($tadam_options["header-logo"]["width"]); ?>" height="<?php echo esc_attr($tadam_options["header-logo"]["height"]); ?>">
		<?php else:?>
			<?php bloginfo('name');?>
		<?php endif; ?>
		</a>
	</h1>
<?php else : ?>
	<p class="site-title logo-title">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
		<?php if($tadam_options["header-logo"]["url"]): ?>
			<img src="<?php echo esc_url($tadam_options["header-logo"]["url"]); ?>" class="custom-logo" alt="" itemprop="logo" data-attachment-id="<?php echo esc_attr($tadam_options["header-logo"]["id"]); ?>" data-permalink="<?php echo esc_url(wp_get_attachment_url( $tadam_options["header-logo"]["id"] )); ?>" width="<?php echo esc_attr($tadam_options["header-logo"]["width"]); ?>" height="<?php echo esc_attr($tadam_options["header-logo"]["height"]); ?>">
                <?php else: ?>
			<?php bloginfo('name');?>
		<?php endif; ?>
		</a>
	</p>
<?php endif;?>

<?php
if($tadam_options["is-sticky-header"]):
?>
	<p class="sticky-site-title logo-title">
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
		<?php if($tadam_options["header-logo"]["url"]): ?>
			<img src="<?php echo esc_url($tadam_options["sticky-header-logo"]["url"]); ?>" class="custom-logo" alt="" itemprop="logo" data-attachment-id="<?php echo esc_attr($tadam_options["sticky-header-logo"]["id"]); ?>" data-permalink="<?php echo esc_url(wp_get_attachment_url( $tadam_options["sticky-header-logo"]["id"] )); ?>" width="<?php echo esc_attr($tadam_options["sticky-header-logo"]["width"]); ?>" height="<?php echo esc_attr($tadam_options["sticky-header-logo"]["height"]); ?>">
		<?php else: ?>
                        <?php bloginfo('name');?>
                <?php endif; ?>
		</a>
	</p>
<?php
endif;


<?php
/**
 * Displays page header
 *
 * @package WordPress
 * @subpackage Tadam_02
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars, $tadam_options;
?>

<?php
$show_title = $tadam_options["page-title"] === 'show' && get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix"] . 'page_title', true ) !== 'hide' || get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix"] . 'page_title', true ) === 'show';

$show_breadcrumbs = $tadam_options["breadcrumbs"] === 'show' && get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix"] . 'breadcrumbs', true ) !== 'hide' || get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix"] . 'breadcrumbs', true ) === 'show';

$slider_id = get_post_meta( get_the_ID(), $tadam_vars["metaboxes_prefix_page_types"] . 'layer-slider', true );
$show_slider = $slider_id > 0;

if ( $show_title || $show_breadcrumbs || $show_slider ):
?>
<div id="title-bar">
	<?php
	if ($show_slider){
		echo do_shortcode('[layerslider id="'.$slider_id.'"]');
	}elseif ( !is_front_page() ){
	?>
		<div class="row align-justify title-bar-wrapper">
			<div class="title-primary column align-self-middle text-<?php echo $tadam_vars["direction"]["text-direction"] ?>">
				<?php if($show_title){
					tadam_wp_title();
				} ?>
			</div>

			<div class="breadcrumbs column align-self-middle text-<?php echo $tadam_vars["direction"]["opposite-direction"] ?> show-for-medium">
				<?php if ($show_breadcrumbs && !is_front_page() && function_exists('yoast_breadcrumb') ) {
                		        yoast_breadcrumb('<div id="breadcrumbs">','</div>');
	                	} ?>
			</div>
        	</div>
	<?php
	}
	?>
</div>
<?php
endif;



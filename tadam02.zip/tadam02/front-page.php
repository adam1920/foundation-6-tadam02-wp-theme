<?php
/**
 * The front page template file
 *
 * If the user has selected a static page for their homepage, this is what will
 * appear.
 * Learn more: https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header(); ?>

<div id="primary" class="content-area">
	<main id="main" class="site-main" role="main">
		
		<div class="row full-width">
			<div class="columns">
				<?php // Show the selected frontpage content.
				if ( have_posts() ) :
					while ( have_posts() ) : the_post();
						get_template_part( 'template-parts/page/content', 'front-page' );
					endwhile;
				else : // I'm not sure it's possible to have no posts when this page is shown, but WTH.
					get_template_part( 'template-parts/post/content', 'none' );
				endif; ?>
			</div>
		</div>

	</main><!-- #main -->
</div><!-- #primary -->

<?php get_footer();

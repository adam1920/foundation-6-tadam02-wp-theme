<?php
/**
 * The template for displaying the footer
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $tadam_vars, $tadam_options;

?>

</div><!-- /#content -->
</div><!-- /.site-content-contain -->


<footer id="colophon" class="site-footer" role="contentinfo">
	<div class="tadam-mask"></div>

	<div class="row">
		<div class="columns medium-4 col-01 col">
			<?php
			if ( is_active_sidebar('footer-one')){
				if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-one')):
		                endif;
			}			
			?>
		</div>
		<div class="columns medium-3 col-02 col">
			<?php
                        if ( is_active_sidebar('footer-two')){
                                if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-two')):
                                endif;
                        } 
                        ?>
		</div>
		<div class="columns medium-2 col-03 col">
			<?php
                        if ( is_active_sidebar('footer-three')){
                                if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-three')):
                                endif;
                        }
                        ?>
		</div>
		<div class="columns medium-3 col-04 col">
			<?php
                        if ( is_active_sidebar('footer-four')){
                                if (!function_exists('dynamic_sidebar') || !dynamic_sidebar('footer-four')):
                                endif;
                        }
                        ?>
		</div>
	</div>

	<div class="row page-footer">
		<div class="columns medium-7 medium-text-<?php echo $tadam_vars["direction"]["default-float"]; ?> text-center">
			<?php echo $tadam_options["footer-copyrights"];?>
		</div>
		<div class="columns medium-2 text-center">
			<?php echo tadam_social_menu(); ?>
		</div>
		<div class="columns medium-3 medium-text-<?php echo $tadam_vars["direction"]["opposite-direction"]; ?> text-center">
			<a class="scrollup" href="#tadam-top"><?php _e('Go to top', 'tadam'); ?></a>
		</div>
	</div>
	<div class="clearfix"></div>
</footer>
</div><!-- /#page -->
<?php wp_footer(); ?>
</body>
</html>


<?php
/**
 * The template for displaying faq archive pages
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Tadam_01
 * @since 0.1
 * @version 0.1
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

get_header();

$terms = get_terms( array(
        'taxonomy'      => 'faq_tag',
        'hide_empty'    => true,
        'order'         => 'ASC'
) );

?>
<div class="row">
        <div class="columns large-8 medium-12 small-12">

        <div id="primary" class="content-area">
                <main id="main" class="site-main" role="main">

			<header class="entry-header">
                                <h1 class="entry-title"><?php tadam_wp_title(); ?></h1>
                        </header>

			<?php if ($terms):?>
        			<div class="sections faq-sections">
        				<?php foreach ($terms as $term){ ?>
						 <section id="faq-section-<?php echo $term->slug; ?>" data-magellan-target="faq-section-<?php echo $term->slug; ?>">
				                        <h2 class="faq-section-title"><?php echo $term->name ?></h2>
                        				<?php
                                			// get faq term items
			                                $args = array(
                        			                'post_type'        => 'faq',
			                                        'showposts'        => -1,
                        			                'suppress_filters' => get_option('suppress_filters'), // WPML filter
			                                        'tax_query' => array(
                        			                        array(
                                                			        'taxonomy' => 'faq_tag',
			                                                        'field'    => 'id',
                        			                                'terms'    => $term->term_id,
			                                                ),
                        			                ),
			                                );
                        			        $faq_query = new WP_Query( $args );
			                                ?>
                        			        <ul class="accordion" data-accordion data-allow-all-closed="true">
			                                <?php
                        			        while ( $faq_query->have_posts() ) : $faq_query->the_post();
								get_template_part( 'template-parts/faq/content', 'accordion-item' );
			                                endwhile;
                        			        ?>
			                                </ul>
                        			        <?php
			                                wp_reset_postdata();
                        				?>
				                </section>
					<?php }	?>
				</div>
				<?php
			else:
				get_template_part( 'template-parts/faq/content', 'none' );
			endif;
			?>
                </main><!-- #main -->
        </div><!-- #primary -->

        </div><!-- /.columns -->

        <div class="columns large-4 medium-12 small-12" data-sticky-container>
                <?php get_sidebar('faq'); ?>
        </div>
</div><!-- .row -->
<?php
get_footer();

